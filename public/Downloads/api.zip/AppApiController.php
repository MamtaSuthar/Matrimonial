<?php

namespace App\Http\Controllers\api;

use DB;
use Session;
use bcrypt;
use Config;
use Redirect;
use App\Helpers\Helpers;
use Hash;
use Mail;
use Cache;
use Crypt;

use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests;
// use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use CfPayout;
use Validator;
use Razorpay\Api\Api;
// use Helpers;
use Log;

class AppApiController extends Controller
{
    public function tempregisteruser(Request $request)
    {
        try {
            Helpers::setHeader(200);
            Helpers::timezone();
            $geturl = Helpers::geturl();
            $input = $request->all();
                
            $validator = Validator::make($input, [
                'fullname' => 'required|min:4',
                'email' => 'required|unique:registerusers|email',
                'password' => 'required|min:4|max:45',
                'mobile' => 'required|numeric|unique:registerusers|digits:10',
            ]);
            // dd('fggf');

            if ($validator->fails()) {
              
                $error = $this->validationHandle($validator->messages());
                return response()->json(array(['success' => false, 'message' => $error]));
            } else {
                // $input['code'] = rand(1000, 9999);
                $input['code'] = 1234;
                $datau['code'] = $input['code'];
                $datau['fullname'] = $input['fullname'];
                $datau['email'] = $input['email'];
                $datau['mobile'] = $input['mobile'];
                $datau['password'] = Hash::make($input['password']);
                $datau['auth_key'] = md5(Hash::make($input['password']));
                if ($request->get('refercode')) {
                    /* check in the register users table */
                    $checkrefercode = DB::table('registerusers')->where('refer_code', $request->get('refercode'))->select('id')->first();
                    if (empty($checkrefercode)) {
                        $json['success'] = false;
                        $json['message'] = 'The entered referred code is not valid. Please enter some valid refer code.';
                        return response()->json(array($json));
                        die;
                    } else {
                        $datau['refer_id'] = $checkrefercode->id;
                    }
                }
                
                $insertid = DB::connection('mysql2')->table('tempuser')->insertGetId($datau);

                $findlogin = DB::table('tempuser')->whereId($insertid)->first();

                // $message = "Your OTP is ".$input['code']." \r\n";
                $message = $input['code'] . " is your OTP for MyPlayerzz11. We never ask for OTP over phone calls or messages. Please don't share this OTP with anyone.";
                // Helpers::sendTextSmsNew($message, $input['mobile']);
                $json['success'] = true;
                $json['message'] = 'OTP sent';
                $json['tempuser'] = base64_encode($insertid);
                // dd($json['tempuser']);
                return response()->json(array($json));
            }
        } catch (\Exception $e) {
            // dd($e);
            return response()->json(array(['success' => false, 'message' => $e->getMessage()]));
        }
    }



    // public function registerusers(request $request)
    // {
    //     try {
    //         Helpers::setHeader(200);
    //         Helpers::timezone();
    //         $geturl = Helpers::geturl();
    //         $formdata = $request->all();
    //         $validator = Validator::make($formdata, [
    //             'tempuser' => 'required',
    //             'otp' => 'required|min:4',
    //         ]);
    //         if ($validator->fails()) {
    //             $error = $this->validationHandle($validator->messages());
    //             return response()->json(array(['success' => false, 'message' => $error]));
    //         } else {
    //             $gid = $request->get('tempuser');
    //              $tempid = base64_decode($gid);
    //             // $tempid = $gid;
            
    //             $code = $request->get('otp');
               
    //             $findifuser = DB::table('tempuser')->where('id', $tempid)->where('code', $code)->first();
    //             // dd($findifuser);
               
    //             if (empty($findifuser)) {
    //                 $json['success'] = false;
    //                 $json['message'] = 'Invalid OTP';
    //                 return response()->json(array($json));
    //                 die;
    //             } else {
    //                // dd($findifuser);
    //                 $input['fullname '] = $findifuser->fullname;
    //                 $input['email'] = $findifuser->email;
    //                 $input['mobile'] = $getnumber = $findifuser->mobile;
    //                 $user_verify['mobile_verify'] = 1;
    //                 $input['password'] = $findifuser->password;
    //                 $input['auth_key'] = $findifuser->auth_key;
    //                 $input['refer_id'] = $findifuser->refer_id;
    //                 $input['status'] = 'activated';
    //                 $input['code'] = '';
    //                 $ff = DB::table('registerusers')->where('email', $findifuser->email)
    //                     ->where('mobile', $findifuser->mobile)->first();
                      
    //                 if (empty($ff)) {
    //                     $getinsertid = DB::connection('mysql2')->table('registerusers')->insertGetId($input);
    //                     // $this->levelincome($getinsertid);
    //                     $user_verify['userid'] = $getinsertid;
    //                     DB::connection('mysql2')->table('user_verify')->insert($user_verify);
    //                     if ($request->get('appid')) {
    //                         $finusers = DB::table('registerusers')->where('id', $getinsertid)->select('id')->first();
    //                         DB::connection('mysql2')->table('androidappid')->where('user_id', $getinsertid)->delete();
    //                         $this->insertAppId($finusers, $request->get('appid'));
    //                     }
    //                     $bonustype = 'mobile';
    //                     $this->registerprocess($request, $getinsertid, $bonustype);
    //                     DB::connection('mysql2')->table('tempuser')->where('id', $findifuser->id)->delete();
    //                 }

                    

    //                 /* delete from temp users */
    //                 $json['success'] = true;
    //                 $json['userid'] = $input['auth_key'];
    //                 $json['auth_key'] = $input['auth_key'];
    //                 $json['name'] = $input['fullname'];
    //                 $json['email'] = $input['email'];
    //                 $json['mobile'] = $input['mobile']; 
    //                 $json['message'] = 'Registration Done';
    //                 return response()->json(array($json));
    //             }
    //         }
    //     } catch (\Exception $e) {
    //         return response()->json(array(['success' => false, 'message' => $e->getMessage()]));
    //     }
    // }


public function registerusers(request $request)
    {
        try {
            Helpers::setHeader(200);
            Helpers::timezone();
            $geturl = Helpers::geturl();
            $formdata = $request->all();

            $validator = Validator::make($formdata, [
                'tempuser' => 'required',
                'otp' => 'required|min:4',
            ]);

            if ($validator->fails()) {
                $error = $this->validationHandle($validator->messages());
                return response()->json(array(['success' => false, 'message' => $error]));
            } else {
                $gid = $request->get('tempuser');
                 $tempid = base64_decode($gid);
                // $tempid = $gid;
            
                $code = $request->get('otp');
               
                $findifuser = DB::table('tempuser')->where('id', $tempid)->where('code', $code)->first();
              //   dd($findifuser);
               
                if (empty($findifuser)) {
                    $json['success'] = false;
                    $json['message'] = 'Invalid OTP';
                    return response()->json(array($json));
                    die;
                } else {

                    $input['email'] = $findifuser->email;
                    $input['fullname'] = $findifuser->fullname;
                    $input['mobile'] = $getnumber = $findifuser->mobile;
                    $user_verify['mobile_verify'] = 1;
                    $input['password'] = $findifuser->password;
                    $input['auth_key'] = $findifuser->auth_key;
                    $input['refer_id'] = $findifuser->refer_id;
                    $input['refer_code'] = 'TK'.$findifuser->fullname.rand(1000,9999);
                    $input['status'] = 1;
                    $input['code'] = '';
                    //dd($input);
                    $ff = DB::table('registerusers')->where('email', $findifuser->email)
                        ->where('mobile', $findifuser->mobile)->first();
                      
                    if (empty($ff)) {
                        $getinsertid = DB::connection('mysql2')->table('registerusers')->insertGetId($input);
                        // $this->levelincome($getinsertid);
                        $userbal['user_id'] = $getinsertid;
                        DB::connection('mysql2')->table('userbalance')->insert($userbal);
                        if ($request->get('appid')) {
                            $finusers = DB::table('registerusers')->where('id', $getinsertid)->select('id')->first();
                            DB::connection('mysql2')->table('androidappid')->where('user_id', $getinsertid)->delete();
                            $this->insertAppId($finusers, $request->get('appid'));
                        }
                        $bonustype = 'mobile';
                        
                        DB::connection('mysql2')->table('tempuser')->where('id', $findifuser->id)->delete();
                    }

                    

                    /* delete from temp users */
                    $json['success'] = true;
                    $json['userid'] = $input['auth_key'];
                    $json['auth_key'] = $input['auth_key'];
                    $json['name'] = $input['fullname'];
                    $json['email'] = $input['email'];
                    $json['mobile'] = $input['mobile'];
                    $json['refer_code'] = $input['refer_code']; 
                    $json['message'] = 'Registration Done';
                    return response()->json(array($json));
                }
            }
        } catch (\Exception $e) {
            return response()->json(array(['success' => false, 'message' => $e->getMessage()]));
       
       }
   }


    public function loginuser(request $request)
    {
        try {
            Helpers::setHeader(200);
            Helpers::timezone();
            $geturl = Helpers::geturl();
            $formdata = $request->all();
            $validator = Validator::make($formdata, [
                'username'             => 'required', 
                'password'          => 'required|min:4',
            ]);
            if ($validator->fails()){
                $error = $this->validationHandle($validator->messages());
                return response()->json(array(['success' => false,'auth_key' => 0,'userid' => 0, 'message' => $error,])); 
            }else{
                $username = $request->get('username');
                $password = $request->get('password');
                $newmailaddress = Helpers::getnewmail($username);
                $findlogin = DB::table('registerusers')
                ->where(function ($query) use ($username, $newmailaddress) {
                    $query->where('email', '=', $username);
                    $query->orWhere('mobile', '=', $username);
                    $query->orwhere('email', '=', $newmailaddress);
                })->first();
                // dd($findlogin);
                if (!empty($findlogin)) {
                    if (Hash::check($password, $findlogin->password)) {
                        if ($findlogin->status == 1) {
                            if ($request->get('appid')) {
                                DB::connection('mysql2')->table('androidappid')->where('user_id',$findlogin->id)->delete();
                                $this->insertAppId($findlogin, $request->get('appid'));
                            }
                            $userd = $findlogin->id . time() . rand(1000, 9999);
                            $authkey = md5(Hash::make($userd));
                            $userdata['auth_key'] = $authkey;
                            DB::connection('mysql2')->table('registerusers')->where('id', $findlogin->id)->update($userdata);
                            // dd($findelogin);
                            $json['success'] = true;
                            $json['auth_key'] = $authkey;
                            $json['userid'] = $authkey;
                            $json['type'] = 'user';
                            $json['mobile'] = ($findlogin->mobile)?$findlogin->mobile:"";
                            $json['email'] = ($findlogin->email)?$findlogin->email:"";
                            $json['name'] = ($findlogin->fullname)?$findlogin->fullname:"";
                            $json['refercode'] = ($findlogin->refer_code)?$findlogin->refer_code:"";
                            $json['wallet_balance'] = '7.00';
                            $json['message'] = 'login successfully';
                            return response()->json(array($json));
                        } else {
                            $json['success'] = false;
                            $json['auth_key'] = 0;
                            $json['userid'] = 0;
                            $json['message'] = 'You cannot login now in this account. Please contact to administartor.';
                            return response()->json(array($json));
                        }
                    } else {
                        $json['success'] = false;
                        $json['auth_key'] = 0;
                        $json['userid'] = 0;
                        $json['message'] = 'Invalid username or Password.';
                        return response()->json(array($json));
                    }
                }else{
                    $json['success'] = false;
                    $json['auth_key'] = 0;
                    $json['userid'] = 0;
                    $json['message'] = 'Invalid username or Password.';
                    return response()->json(array($json));
                }
            }
        } catch (\Exception $e) { 
            Log::info($e->getMessage());
            return response()->json(array(['success' => false,'auth_key' => 0,'userid' => 0, 'message' => $e->getMessage()])); 
        }
    }


    public function resendotp(Request $request)
    {
        Helpers::setHeader(200);
        // if($request->isMethod('post')){
        if ($request->get('tempuser')) {
            $gid = $request->get('tempuser');
            $id = base64_decode($gid);
            $checkdata = DB::table('tempuser')->where('id', $id)->first();
            if (!empty($checkdata)) {
                $code = $checkdata->code;
                $mobile = $checkdata->mobile;
                $message = $code . " is the OTP for your " . (Helpers::settings()->project_name ?? '') . " account. NEVER SHARE YOUR OTP WITH ANYONE. " . (Helpers::settings()->project_name ?? '') . " will never call or message to ask for the OTP.";

                Helpers::sendTextSmsNew($message, $mobile);

                $json['success'] = true;
                $json['message'] = 'OTP Send';
                return response()->json(array($json));
                die;
            } else {
                $json['success'] = false;
                $json['message'] = 'Invalid id provide';
                return response()->json(array($json));
                die;
            }
        }
        if ($request->get('mobile')) {
            $mobile = $request->get('mobile');
            $checkdata1 = DB::table('registerusers')->where('mobile', $mobile)->first();
            if (!empty($checkdata1)) {
                $code1 = $checkdata1->code;
                $mobile1 = $checkdata1->mobile;
                $message1 = $code1 . "  is the OTP for your " . (Helpers::settings()->project_name ?? '') . " account. NEVER SHARE YOUR OTP WITH ANYONE. " . (Helpers::settings()->project_name ?? '') . " will never call or message to ask for the OTP.";
                Helpers::sendTextSmsNew($message1, $mobile1);
                $json['success'] = true;
                $json['message'] = 'OTP Send';
                return response()->json(array($json));
                die;
            } else {
                $json['success'] = false;
                $json['message'] = 'Invalid id provide';
                return response()->json(array($json));
                die;
            }
        }
        if ($request->get('email')) {
            $email = $request->get('email');
            $checkdata1 = DB::table('registerusers')->where('email', $email)->first();
            if (!empty($checkdata1)) {
                $emailsubject = 'Activate Account - ' . Helpers::settings()->project_name ?? '';
                $content = '<tr>
                        <td style="padding:20px 20px 0px 20px" align="left">
                        <div style="font-family:Roboto,Arial,Helvetica;font-size:15px;line-height:22px;color:#4e4e4e">Hello <strong>user</strong> Welcome to ' . (Helpers::settings()->project_name ?? '') . '.Join the best community of Fans. Come play our Fantasy Cricket.<br> To verify your email account please use this OTP <strong>' . $checkdata1->code . '</strong>
                        </div>
                        </td>
                    </tr>';
                $msg = Helpers::mailbody1($content);
                $datamessage['email'] =  $checkdata1->email;
                $datamessage['subject'] = $emailsubject;
                $datamessage['content'] = $msg;
                // Helpers::mailsentFormat($checkdata1->$email, $emailsubject, $msg);
                $json['success'] = true;
                $json['message'] = 'OTP Send';
                return response()->json($json);
                die;
            } else {
                $json['success'] = false;
                $json['message'] = 'Invalid id provide';
                return response()->json($json);
                die;
            }
        } else {
            $json['success'] = false;
            $json['message'] = 'Unauthorized Request';
            return response()->json(array($json));
            die;
        }
        // }
    }

    public function getmainbanner(Request $request)
    {
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $user = Helpers::isAuthorize($request);
        if(!empty($user)){
        $json = array();
        $findsidebanner = DB::table('sidebanner')->get();
        if (!empty($findsidebanner)) {
            $i = 0;
            foreach ($findsidebanner as $value) {
                $json[$i]['image'] = $geturl . 'public/' . $value->image;
                $json[$i]['type'] = $value->type;
                $json[$i]['url'] = ( !empty($value->url) ) ? $value->url : '';
                $i++;
            }
            return response()->json($json);
            die;
        }
    }
    }
  
    public function category(Request $request)
    {
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $user = Helpers::isAuthorize($request);
        if(!empty($user)){
        $json = array();
        $findcategory = DB::table('category')->get();
       //dd($findcategory);
        if (!empty($findcategory)) {
            $i = 0;
            foreach ($findcategory as $value) {
                $json[$i]['category_id'] = $value->id;
                $json[$i]['image'] = $geturl . 'public/' . $value->image;
                $json[$i]['status'] = $value->status;
                $json[$i]['category_name'] = $value->category_name;
               // $json[$i]['url'] = ( !empty($value->url) ) ? $value->url : '';
                $i++;
            }
            return response()->json($json);
            die;
        }
    }
    }

    //newUpdate
    public function products(Request $request){
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $user = Helpers::isAuthorize($request);
        $user_id = $user->id;
        $quen = Helpers::CartProductQuan($user_id);
        if(!empty($user)){
            $json = array();
            $findproducts = DB::table('products')->get();
        
            if (!empty($findproducts)) {

                $i = 0;
                foreach ($findproducts as $value) {
                    $joy['product_id'] = $value->product_id;
                    $ratting = DB::table('product_review')->where('product_id',$joy['product_id'])->where('status',1)->select('user_name','ratting','review','user_image','date')->get();
                  
                    $countproductid = DB::table('product_review')->where('product_id',$joy['product_id'])->where('status',1)->select('product_id')->count(); 
                   //average ratting loop
                    $j = 0;
                    $total =0;
                  
                    if(!empty($ratting)){
                        foreach($ratting as $rate){
                            // $dd =$rate;
                            // $datass[] = $dd; 
                            $total = $total+$rate->ratting;
                            // $rattingdata=json_decode($ratting); 
                            $j++;
                        }
                    }
                   //end avearage ratting loop
                   
                    $findoffers = DB::table('offers')->where('product_id',$joy['product_id'])->select('bonus','bonus_type','product_id')->first();
                    $checkdata= DB::table('registerusers')->where('id',$user->id)->value('wishlist');
                    $data=json_decode($checkdata);
                    if($value->is_featured==1){
                        if(!empty($quen)){
                            if(in_array($value->product_id,$quen)){
                                $quen11 = Helpers::CartProductQuan1($user_id,$value->product_id);
                                $Featured[$i]['product_qty'] = $quen11;
                            }else{
                                $Featured[$i]['product_qty'] = 0;
                            }
                        }else{
                            $Featured[$i]['product_qty'] = 0;
                        }
                        $Featured[$i]['product_id'] = $value->product_id;
                        $Featured[$i]['product_images'] = $geturl . 'public/uploads/product_image/' . $value->main_image;
                        $Featured[$i]['title'] = $value->title;
                        $Featured[$i]['subtitle'] = $value->subtitle;
                        $Featured[$i]['quantity'] = $value->quantity;
                        $Featured[$i]['purchase_price'] = $value->purchase_price;
                        $Featured[$i]['sale_price'] = $value->sale_price;
                        $Featured[$i]['description'] = $value->description;
                        $Featured[$i]['discount'] = ($findoffers!="")?$findoffers->bonus:"";
                        $Featured[$i]['discount_type'] = ($findoffers!="")?strval($findoffers->bonus_type):"";
                        $Featured[$i]['reviewdata'] = $ratting;
        
                             
                            if($countproductid == 0){
                                $Featured[$i]['ratting'] = 0;
                            }else{
                                $avgratting = ($total/$countproductid);
                                $Featured[$i]['ratting'] =$avgratting ;
                            }
                            if(!empty($data)){
                                $aa = array_column($data , 'product_id');
                                if(in_array($value->product_id,$aa)){
                                    $Featured[$i]['whislist'] = 1;
                                }else{
                                    $Featured[$i]['whislist'] = 0;
                                }
                            } 

                    }

                    if($value->is_deal_day==1){
                        if(!empty($quen)){
                            if(in_array($value->product_id,$quen)){
                                $quen11 = Helpers::CartProductQuan1($user_id,$value->product_id);
                    
                                $DOFDAY[$i]['product_qty'] = $quen11;
                            }else{
                                $DOFDAY[$i]['product_qty'] = 0;
                            }
                        }else{
                            $DOFDAY[$i]['product_qty'] = 0;
                        }
                        $DOFDAY[$i]['product_id'] = $value->product_id;
                        $DOFDAY[$i]['product_images'] = $geturl . 'public/uploads/product_image/' . $value->main_image;
                        $DOFDAY[$i]['title'] = $value->title;
                        $DOFDAY[$i]['subtitle'] = $value->subtitle;
                        $DOFDAY[$i]['quantity'] = $value->quantity;
                        $DOFDAY[$i]['purchase_price'] = $value->purchase_price;
                        $DOFDAY[$i]['sale_price'] = $value->sale_price;
                        $DOFDAY[$i]['description'] = $value->description;
                        $DOFDAY[$i]['discount'] = ($findoffers!="")?$findoffers->bonus:"";
                        $DOFDAY[$i]['discount_type'] = ($findoffers!="")?strval($findoffers->bonus_type):"";
                        $DOFDAY[$i]['reviewdata'] = $ratting;

                        if($countproductid == 0){
                            $DOFDAY[$i]['ratting'] = 0;
                        }else{
                            $avgratting = ($total/$countproductid);
                            $DOFDAY[$i]['ratting'] =$avgratting ;
                        }
                
                        if(!empty($data)){
                            $aa = array_column($data , 'product_id');
                            if(in_array($value->product_id,$aa)){
                                $DOFDAY[$i]['whislist'] = 1;
                            }else{
                                $DOFDAY[$i]['whislist'] = 0;
                            }
                        } 
                    }

                    if($value->is_featured !=1){

                        if(!empty($quen)){
                            if(in_array($value->product_id,$quen)){
                                $quen11 = Helpers::CartProductQuan1($user_id,$value->product_id);
                    
                                $Products[$i]['product_qty'] = $quen11;
                            }else{
                                $Products[$i]['product_qty'] = 0;
                            }
                        }else{
                            $Products[$i]['product_qty'] = 0;
                        }
                
                        $Products[$i]['product_id'] = $value->product_id;
                        $Products[$i]['product_images'] = $geturl . 'public/uploads/product_image/' . $value->main_image;
                        $Products[$i]['title'] = $value->title;
                        $Products[$i]['subtitle'] = $value->subtitle;
                        $Products[$i]['quantity'] = $value->quantity;
                        $Products[$i]['purchase_price'] = $value->purchase_price;
                        $Products[$i]['sale_price'] = $value->sale_price;
                        $Products[$i]['description'] = $value->description;
                        $Products[$i]['discount'] = ($findoffers!="")?$findoffers->bonus:"";
                        $Products[$i]['discount_type'] = ($findoffers!="")?strval($findoffers->bonus_type):"";
                        $Products[$i]['reviewdata'] = $ratting;
                        if($countproductid == 0){
                            $Products[$i]['ratting'] = 0;
                        }else{
                            $avgratting = ($total/$countproductid);
                            $Products[$i]['ratting'] =$avgratting ;
                        }
                        if(!empty($data)){
                            $aa = array_column($data , 'product_id');
                            if(in_array($value->product_id,$aa)){
                                $Products[$i]['whislist'] = 1;
                            }else{
                                $Products[$i]['whislist'] = 0;
                            }
                        } 
                    }

                    $i++;
                }
        
                $json['Feature'] = array_values($Featured);
                $json['Dealofday'] = array_values($DOFDAY);
                $json['Products'] = array_values($Products);
                return response()->json(array($json));
                die;
            }
        }
    }

    //Update whislist product update
    // public function products(Request $request){
    //     Helpers::setHeader(200);
    //     Helpers::timezone();
    //     $geturl = Helpers::geturl();
    //     $user = Helpers::isAuthorize($request);
    //     $user_id = $user->id;
    //     $quen = Helpers::CartProductQuan($user_id);
    //     if(!empty($user)){
    //         $json = array();
    //         $findproducts = DB::table('products')->get();
        
    //         if (!empty($findproducts)) {

    //             $i = 0;

    //             foreach ($findproducts as $value) {
    //                 $joy['product_id'] = $value->product_id;
    //                 $findoffers = DB::table('offers')->where('product_id',$joy['product_id'])->select('bonus','bonus_type','product_id')->first();
    //                 $checkdata= DB::table('registerusers')->where('id',$user->id)->value('wishlist');
    //                 $data=json_decode($checkdata);

    //                 if($value->is_featured==1){
    //                     if(!empty($quen)){
    //                         if(in_array($value->product_id,$quen)){
    //                             $quen11 = Helpers::CartProductQuan1($user_id,$value->product_id);
    //                             $Featured[$i]['product_qty'] = $quen11;
    //                         }else{
    //                             $Featured[$i]['
    //                             '] = 0;
    //                         }
    //                     }else{
    //                         $Featured[$i]['product_qty'] = 0;
    //                     }
        
    //                     $Featured[$i]['product_id'] = $value->product_id;
    //                     $Featured[$i]['product_images'] = $geturl . 'public/uploads/product_image/' . $value->main_image;
    //                     $Featured[$i]['title'] = $value->title;
    //                     $Featured[$i]['subtitle'] = $value->subtitle;
    //                     $Featured[$i]['quantity'] = $value->quantity;
    //                     $Featured[$i]['purchase_price'] = $value->purchase_price;
    //                     $Featured[$i]['sale_price'] = $value->sale_price;
    //                     $Featured[$i]['description'] = $value->description;
    //                     $Featured[$i]['discount'] = ($findoffers!="")?$findoffers->bonus:"";
    //                     $Featured[$i]['discount_type'] = ($findoffers!="")?strval($findoffers->bonus_type):"";

                        
    //                 if(!empty($data)){
    //                     $aa = array_column($data , 'product_id');
    //                     if(in_array($value->product_id,$aa)){
    //                         $Featured[$i]['whislist'] = 1;
    //                     }else{
    //                         $Featured[$i]['whislist'] = 0;
    //                     }
    //                 }                           
    //                 }

    //                 if($value->is_deal_day==1){
    //                     if(!empty($quen)){
    //                         if(in_array($value->product_id,$quen)){
    //                             $quen11 = Helpers::CartProductQuan1($user_id,$value->product_id);
                    
    //                             $DOFDAY[$i]['product_qty'] = $quen11;
    //                         }else{
    //                             $DOFDAY[$i]['product_qty'] = 0;
    //                         }
    //                     }else{
    //                         $DOFDAY[$i]['product_qty'] = 0;
    //                     }
    //                     $DOFDAY[$i]['product_id'] = $value->product_id;
    //                     $DOFDAY[$i]['product_images'] = $geturl . 'public/uploads/product_image/' . $value->main_image;
    //                     $DOFDAY[$i]['title'] = $value->title;
    //                     $DOFDAY[$i]['subtitle'] = $value->subtitle;
    //                     $DOFDAY[$i]['quantity'] = $value->quantity;
    //                     $DOFDAY[$i]['purchase_price'] = $value->purchase_price;
    //                     $DOFDAY[$i]['sale_price'] = $value->sale_price;
    //                     $DOFDAY[$i]['description'] = $value->description;
    //                     $DOFDAY[$i]['discount'] = ($findoffers!="")?$findoffers->bonus:"";
    //                     $DOFDAY[$i]['discount_type'] = ($findoffers!="")?strval($findoffers->bonus_type):"";
                
    //                 if(!empty($data)){
    //                     $aa = array_column($data , 'product_id');
    //                     if(in_array($value->product_id,$aa)){
    //                         $DOFDAY[$i]['whislist'] = 1;
    //                     }else{
    //                         $DOFDAY[$i]['whislist'] = 0;
    //                     }
    //                 } 
    //                 }

    //                 if($value->is_featured !=1){

    //                     if(!empty($quen)){
    //                         if(in_array($value->product_id,$quen)){
    //                             $quen11 = Helpers::CartProductQuan1($user_id,$value->product_id);
                    
    //                             $Products[$i]['product_qty'] = $quen11;
    //                         }else{
    //                             $Products[$i]['product_qty'] = 0;
    //                         }
    //                     }else{
    //                         $Products[$i]['product_qty'] = 0;
    //                     }
                
    //                     $Products[$i]['product_id'] = $value->product_id;
    //                     $Products[$i]['product_images'] = $geturl . 'public/uploads/product_image/' . $value->main_image;
    //                     $Products[$i]['title'] = $value->title;
    //                     $Products[$i]['subtitle'] = $value->subtitle;
    //                     $Products[$i]['quantity'] = $value->quantity;
    //                     $Products[$i]['purchase_price'] = $value->purchase_price;
    //                     $Products[$i]['sale_price'] = $value->sale_price;
    //                     $Products[$i]['description'] = $value->description;
    //                     $Products[$i]['discount'] = ($findoffers!="")?$findoffers->bonus:"";
    //                     $Products[$i]['discount_type'] = ($findoffers!="")?strval($findoffers->bonus_type):"";
    //                     if(!empty($data)){
    //                         $aa = array_column($data , 'product_id');
    //                         if(in_array($value->product_id,$aa)){
    //                             $Products[$i]['whislist'] = 1;
    //                         }else{
    //                             $Products[$i]['whislist'] = 0;
    //                         }
    //                     } 
    //                 }

    //                 $i++;
    //             }
        
    //             $json['Feature'] = array_values($Featured);
    //             $json['Dealofday'] = array_values($DOFDAY);
    //             $json['Products'] = array_values($Products);
    //             return response()->json(array($json));
    //             die;
    //         }
    //     }
    // }


    ///////end

    // public function products(Request $request)
    // {    
    //     Helpers::setHeader(200);
    //     Helpers::timezone();
    //     $geturl = Helpers::geturl();
    //     $user = Helpers::isAuthorize($request);
    //     $user_id = $user->id;
    //     $quen = Helpers::CartProductQuan($user_id);
    //     if(!empty($user)){
    //     $json = array();
    //     $findproducts = DB::table('products')->get();
        
    //     if (!empty($findproducts)) {
    //         $i = 0;
    //         foreach ($findproducts as $value) {
    //             $joy['product_id'] = $value->product_id;
    //             $findoffers = DB::table('offers')->where('product_id',$joy['product_id'])->select('bonus','bonus_type','product_id')->first();

    //             if($value->is_featred==1){

    //                 if(!empty($quen)){
    //                      if(in_array($value->product_id,$quen)){
    //                         $quen11 = Helpers::CartProductQuan1($user_id,$value->product_id);
                    
    //                         $Featured[$i]['product_qty'] = $quen11;
    //                     }else{
    //                         $Featured[$i]['
    //                         '] = 0;
    //                     }
    //                 }else{
    //                     $Featured[$i]['product_qty'] = 0;
    //                 }

    //                 $Featured[$i]['product_id'] = $value->product_id;
    //                 $Featured[$i]['product_images'] = $geturl . 'public/uploads/product_image/' . $value->main_image;
    //                 $Featured[$i]['title'] = $value->title;
    //                 $Featured[$i]['subtitle'] = $value->subtitle;
    //                 $Featured[$i]['quantity'] = $value->quantity;
    //                 $Featured[$i]['purchase_price'] = $value->purchase_price;
    //                 $Featured[$i]['sale_price'] = $value->sale_price;
    //                 $Featured[$i]['description'] = $value->description;
    //                 $Featured[$i]['discount'] = ($findoffers!="")?$findoffers->bonus:"";
    //                 $Featured[$i]['discount_type'] = ($findoffers!="")?strval($findoffers->bonus_type):"";
    //             }
    //             if($value->is_deal_day==1){

    //                 if(!empty($quen)){
    //                      if(in_array($value->product_id,$quen)){
    //                         $quen11 = Helpers::CartProductQuan1($user_id,$value->product_id);
                    
    //                         $DOFDAY[$i]['product_qty'] = $quen11;
    //                     }else{
    //                         $DOFDAY[$i]['product_qty'] = 0;
    //                     }
    //                 }else{
    //                     $DOFDAY[$i]['product_qty'] = 0;
    //                 }

    //                 $DOFDAY[$i]['product_id'] = $value->product_id;
    //                 $DOFDAY[$i]['product_images'] = $geturl . 'public/uploads/product_image/' . $value->main_image;
    //                 $DOFDAY[$i]['title'] = $value->title;
    //                 $DOFDAY[$i]['subtitle'] = $value->subtitle;
    //                 $DOFDAY[$i]['quantity'] = $value->quantity;
    //                 $DOFDAY[$i]['purchase_price'] = $value->purchase_price;
    //                 $DOFDAY[$i]['sale_price'] = $value->sale_price;
    //                 $DOFDAY[$i]['description'] = $value->description;
    //                 $DOFDAY[$i]['discount'] = ($findoffers!="")?$findoffers->bonus:"";
    //                 $DOFDAY[$i]['discount_type'] = ($findoffers!="")?strval($findoffers->bonus_type):"";
    //                // $json[$i]['url'] = ( !empty($value->url) ) ? $value->url : '';
    //             }
    //             if($value->is_featured !=1){

    //                 if(!empty($quen)){
    //                      if(in_array($value->product_id,$quen)){
    //                         $quen11 = Helpers::CartProductQuan1($user_id,$value->product_id);
                    
    //                         $Products[$i]['product_qty'] = $quen11;
    //                     }else{
    //                         $Products[$i]['product_qty'] = 0;
    //                     }
    //                 }else{
    //                     $Products[$i]['product_qty'] = 0;
    //                 }
                
    //                 $Products[$i]['product_id'] = $value->product_id;
    //                 $Products[$i]['product_images'] = $geturl . 'public/uploads/product_image/' . $value->main_image;
    //                 $Products[$i]['title'] = $value->title;
    //                 $Products[$i]['subtitle'] = $value->subtitle;
    //                 $Products[$i]['quantity'] = $value->quantity;
    //                 $Products[$i]['purchase_price'] = $value->purchase_price;
    //                 $Products[$i]['sale_price'] = $value->sale_price;
    //                 $Products[$i]['description'] = $value->description;
    //                 $Products[$i]['discount'] = ($findoffers!="")?$findoffers->bonus:"";
    //                 $Products[$i]['discount_type'] = ($findoffers!="")?strval($findoffers->bonus_type):"";
    //                // $json[$i]['url'] = ( !empty($value->url) ) ? $value->url : '';
    //             }
    //             $i++;
    //         }
    //         $json['Feature'] = array_values($Featured);
    //         $json['Dealofday'] = array_values($DOFDAY);
    //         $json['Products'] = array_values($Products);
    //         return response()->json(array($json));
    //         die;
    //     }
    //     }
    // }
    
    // public function subcategory(Request $request)
    // {
    //     Helpers::setHeader(200);
    //     Helpers::timezone();
    //     $geturl = Helpers::geturl();
    //     $user = Helpers::isAuthorize($request);
    //     if(!empty($user)){
    //     $json = array();
    //     $findsubcategory = DB::table('subcategory')->get();
    //    //dd($findcategory);
    //     if (!empty($findsubcategory)) {
    //         $i = 0;
    //         foreach ($findsubcategory as $value) {
    //             $json[$i]['image'] = $geturl . 'public/' . $value->image;
    //             $json[$i]['status'] = $value->status;
    //             $json[$i]['subcategory_id'] = $value->id;
    //             $json[$i]['category_id'] = $value->category_id;
    //             $json[$i]['subcategory_name'] = $value->subcategory_name;
    //            // $json[$i]['url'] = ( !empty($value->url) ) ? $value->url : '';
    //             $i++;
    //         }
    //         return response()->json($json);
    //         die;
    //     }
    // }
    // }

    //27
    public function subcategory(Request $request)
    {
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $user = Helpers::isAuthorize($request);
        if(!empty($user)){
        $json = array();
        $category_id = $request->get('category_id');
        if($category_id==""){
            $json['status'] = true;
            $json['message'] = 'Category ID Required';
            return response()->json($json);
            die;
        }
        $findsubcategory = DB::table('subcategory')->where('category_id',$category_id)->get();
       //dd($findcategory);
        if (!empty($findsubcategory)) {
            $i = 0;
            foreach ($findsubcategory as $value) {
                $json[$i]['image'] = $geturl . 'public/' . $value->image;
                $json[$i]['status'] = $value->status;
                $json[$i]['subcategory_id'] = $value->id;
                $json[$i]['category_id'] = $value->category_id;
                $json[$i]['subcategory_name'] = $value->subcategory_name;
               // $json[$i]['url'] = ( !empty($value->url) ) ? $value->url : '';
                $i++;
            }
            // return response()->json($json);
            return response()->json($json);
            die;
        }
    }
    }

      
    // public function searchproduct(Request $request)
    // {
    //     Helpers::setHeader(200);
    //     Helpers::timezone();
    //     $geturl = Helpers::geturl();
    //     $user = Helpers::isAuthorize($request);
    //     $user_id = $user->id;
    //     $quen = Helpers::CartProductQuan($user_id);
    //     $getusername = $request->get('title');
    //     $json = array();
    //     if(!empty($getusername)){
    //         $getdata = DB::table('products')->where('title','LIKE','%'.$getusername.'%')->get();
    //         if(!empty($getdata)){
    //            $i=0;
    //             foreach($getdata as $getdatas){
    //                        if(!empty($quen)){
    //                      if(in_array($getdatas->product_id,$quen)){
    //                         $quen11 = Helpers::CartProductQuan1($user_id,$getdatas->product_id);
                    
    //                         $json[$i]['product_qty'] = $quen11;
    //                     }else{
    //                         $json[$i]['
    //                         '] = 0;
    //                     }
    //                 }else{
    //                     $json[$i]['product_qty'] = 0;
    //                 }

    //                     $joy['product_id'] = $getdatas->product_id;
    //                     $findoffers = DB::table('offers')->where('product_id',$joy['product_id'])->select('bonus','bonus_type','product_id')->first();

    //                    if(!empty($findoffers)){
    //                       // dd($findoffers->bonus);
    //                      $json[$i]['discount'] = $findoffers->bonus;
    //                      $json[$i]['discount_type'] = $findoffers->bonus_type;


    //                   }else{
    //                      $json[$i]['discount'] = "";
    //                      $json[$i]['discount_type'] = "";

    //                }
    //                     $json[$i]['product_id'] = $getdatas->product_id;
    //                     // $productimages = explode('$',$geturl . 'public/' . $getdatas->product_images);
    //                      $array = explode('{$}',$getdatas->product_images);
    //                      foreach ($array as $value) {
    //                         $image[0] =$geturl . 'public/uploads/product_image/' . $value;
    //                      }
    //                      $json[$i]['product_images'] =$image[0];

    //                    //$json[$i]['product_images'] = $geturl . 'public/uploads/product_image/' . $getdatas->product_images;
    //                     $json[$i]['title'] = $getdatas->title;
    //                     $json[$i]['subtitle'] = $getdatas->subtitle;
    //                     $json[$i]['purchase_price'] = $getdatas->purchase_price;
    //                     $json[$i]['sale_price'] = $getdatas->sale_price;
    //                     $json[$i]['quantity'] = $getdatas->quantity;
    //                     // $json[$i]['dob'] = $getdatas->dob;
    //                     $i++;
    //             } 
    //             return response()->json($json);
    //         }
    //     }else{
    //         $json['success'] = false;
    //         $json['message'] = 'Enter Required Field!';
    //         return response()->json($json);
    //     }
    // }

    public function searchproduct(Request $request)
    {
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $user = Helpers::isAuthorize($request);
        $user_id = $user->id;
        $quen = Helpers::CartProductQuan($user_id);
        $getusername = $request->get('title');
        $json = array();
        if(!empty($getusername)){
            $getdata = DB::table('products')->where('title','LIKE','%'.$getusername.'%')->get();
            if(!empty($getdata)){
               $i=0;
                foreach($getdata as $getdatas){
                    if(!empty($quen)){
                        if(in_array($getdatas->product_id,$quen)){
                            $quen11 = Helpers::CartProductQuan1($user_id,$getdatas->product_id);
                    
                            $json[$i]['product_qty'] = $quen11;
                        }else{
                            $json[$i]['
                            '] = 0;
                        }
                    }else{
                        $json[$i]['product_qty'] = 0;
                    }

                    $joy['product_id'] = $getdatas->product_id;
                    $findoffers = DB::table('offers')->where('product_id',$joy['product_id'])->select('bonus','bonus_type','product_id')->first();

                    if(!empty($findoffers)){
                          // dd($findoffers->bonus);
                        $json[$i]['discount'] = $findoffers->bonus;
                        $json[$i]['discount_type'] = $findoffers->bonus_type;
                    }else{
                        $json[$i]['discount'] = "";
                        $json[$i]['discount_type'] = "";
                    }
                        $json[$i]['product_id'] = $getdatas->product_id;
                        // $productimages = explode('$',$geturl . 'public/' . $getdatas->product_images);
                        $array = explode('{$}',$getdatas->product_images);
                    foreach ($array as $value) {
                        $image[0] =$geturl . 'public/uploads/product_image/' . $value;
                    }
                    $checkdata= DB::table('registerusers')->where('id',$user->id)->value('wishlist');
                    $data=json_decode($checkdata);
                    $json[$i]['product_images'] =$image[0];

                    //$json[$i]['product_images'] = $geturl . 'public/uploads/product_image/' . $getdatas->product_images;
                    $json[$i]['title'] = $getdatas->title;
                    $json[$i]['subtitle'] = $getdatas->subtitle;
                    $json[$i]['purchase_price'] = $getdatas->purchase_price;
                    $json[$i]['sale_price'] = $getdatas->sale_price;
                    $json[$i]['quantity'] = $getdatas->quantity;
                    // $json[$i]['dob'] = $getdatas->dob;
                    
                    if(!empty($data)){
                        $aa = array_column($data , 'product_id');
                        if(in_array($getdatas->product_id,$aa)){
                            $json[$i]['whislist'] = 1;
                        }else{
                            $json[$i]['whislist'] = 0;
                        }
                    }else{
                        $json[$i]['whislist'] = 0;
                    }
                    $i++;
                } 
                return response()->json($json);
            }
        }else{
            $json['success'] = false;
            $json['message'] = 'Enter Required Field!';
            return response()->json($json);
        }
    }

    //end
   
    // public function singleproduct(Request $Request)
    // {
    //     Helpers::setHeader(200);
    //     Helpers::timezone();
    //     $geturl = Helpers::geturl();
    //     $user = Helpers::isAuthorize($Request);
    //     $getusername = $Request->get('id');
    //     $json = array();
    //     if(!empty($getusername)){
    //         $getdata = DB::table('products')->where('product_id','LIKE','%'.$getusername.'%')->get();
    //         if(!empty($getdata)){
    //             $i=0;
    //             foreach($getdata as $getdatas){
    //                 $json[$i]['product_id'] = $getdatas->product_id;
    //                 $json[$i]['product_images'] = $geturl . 'public/' . $getdatas->product_images;
    //                 $json[$i]['title'] = $getdatas->title;
    //                 $json[$i]['subtitle'] = $getdatas->subtitle;
    //                 $json[$i]['purchase_price'] = $getdatas->purchase_price;
    //                 $json[$i]['sale_price'] = $getdatas->sale_price;
    //                 $json[$i]['discount'] = $getdatas->discount;
    //                 $json[$i]['description'] = $getdatas->description;
    //                 $i++;
    //                 return response()->json($json);
    //             }
    //         }else{
    //             $json['success'] = false;
    //             $json['message'] = 'Enter Required Field!';
    //             return response()->json($json);
    //         }
    //     }
    // }
        
        //  19feb 
        // public function singleproduct(Request $Request)
        // {
        //     Helpers::setHeader(200);
        //     Helpers::timezone();
        //     $geturl = Helpers::geturl();
        //     $user = Helpers::isAuthorize($Request);

        //     $user_id = $user->id;
        //     $quen = Helpers::CartProductQuan($user_id);
        //     $getusername = $Request->get('id');
        //     $json = array();
        //     if(!empty($getusername)){
        //         $getdata = DB::table('products')->where('product_id',$getusername)->first();
        //         if(!empty($getdata)){
        //             $getrealtedprod = DB::table('products')->where('product_id','!=',$getusername)->where('category',$getdata->category)->get();
        //             if(!empty($getrealtedprod->toArray())){
        //                 $r=0;
        //                 foreach ($getrealtedprod as $key => $value) {

        //                     $joy['product_id'] = $value->product_id;
        //                     $findoffers = DB::table('offers')->where('product_id',$joy['product_id'])->select('bonus','bonus_type','product_id')->first();

        //                     if(in_array($value->product_id,$quen)){
        //                         $quen11 = Helpers::CartProductQuan1($user_id,$value->product_id);
        //                     // dump($quen11);
        //                         $json['related_products'][$r]['product_qty'] = $quen11;
        //                     }else{
        //                         $json['related_products'][$r]['product_qty'] = 0;
        //                     }
        //                     $json['related_products'][$r]['product_id'] = $value->product_id;
        //                     //$json['related_products'][$r]['product_images']= $geturl . 'public/uploads/product_image/' . $value->product_images;
        //                     $new_array = explode('{$}',$value->product_images);
        //                     foreach ($new_array as $val) { 
        //                     $img[0] = $geturl . 'public/uploads/product_image/' . $val;
        //                     }
        //                     $json['related_products'][$r]['product_images']=$img[0];
        //                     $json['related_products'][$r]['title'] = $value->title;
        //                     $json['related_products'][$r]['subtitle'] = $value->subtitle;
        //                     $json['related_products'][$r]['purchase_price'] = $value->purchase_price;
        //                     $json['related_products'][$r]['sale_price'] = $value->sale_price;
        //                     $json['related_products'][$r]['description'] = $value->description;
        //                     // $json['related_products'][$r]['discount'] = $value->discount;
        //                     $json['related_products'][$r]['quantity'] = $value->quantity;
        //                     $json['related_products'][$r]['discount'] = ($findoffers!="")?strval($findoffers->bonus):"";
        //                     $json['related_products'][$r]['discount_type'] = ($findoffers!="")?"$findoffers->bonus_type":"";
        //                     $r++;
        //                 }
        //             }else{
        //                 $json['related_products'] = [];
        //             }


        //             $findoffers2 = DB::table('offers')->where('product_id',$getdata->product_id)->select('bonus','bonus_type','product_id')->first();
        //             if(in_array($getdata->product_id,$quen)){
        //                 $quen11 = Helpers::CartProductQuan1($user_id,$getdata->product_id);
        //             // dump($quen11);
        //                 $json['product_qty'] = $quen11;
        //             }else{
        //                 $json['product_qty'] = 0;
        //             }
        //             $json['product_id'] = $getdata->product_id;
        //         // $json['product_images'] = $geturl . 'public/uploads/product_image/' . $getdata->product_images;
        //             $array = explode('{$}',$getdata->product_images);
        //                     foreach ($array as $val) { 
        //                     $json['product_images'][] = $geturl . 'public/uploads/product_image/' . $val;
        //                     }
        //             $json['title'] = $getdata->title;
        //             $json['subtitle'] = $getdata->subtitle;
        //             $json['purchase_price'] = $getdata->purchase_price;
        //             $json['sale_price'] = $getdata->sale_price;
        //             // $json['discount'] = $getdata->discount;
        //             $json['description'] = $getdata->description;
        //             $json['quantity'] = $getdata->quantity;
        //             $json['discount'] = ($findoffers2!="")?strval($findoffers2->bonus):"";
        //             $json['discount_type'] = ($findoffers2!="")?"$findoffers2->bonus_type":"";
        //             return response()->json(array($json));                
        //         }else{
        //             $json['success'] = false;
        //             $json['related_products'] = 0;
        //             $json['message'] = 'Enter Required Field!';
        //             return response()->json($json);
        //         }
        //     }
        // }

            
    // public function singleproduct(Request $Request){
    //     Helpers::setHeader(200);
    //     Helpers::timezone();
    //     $geturl = Helpers::geturl();
    //     $user = Helpers::isAuthorize($Request);

    //     $user_id = $user->id;
    //     $quen = Helpers::CartProductQuan($user_id);
    //     $getusername = $Request->get('id');
    //     $json = array();
    //     if(!empty($getusername)){
    //         $getdata = DB::table('products')->where('product_id',$getusername)->first();
    //         if(!empty($getdata)){
    //             $getrealtedprod = DB::table('products')->where('product_id','!=',$getusername)->where('category',$getdata->category)->get();
    //             if(!empty($getrealtedprod->toArray())){
    //                 $r=0;
    //                 foreach ($getrealtedprod as $key => $value) {

    //                     $joy['product_id'] = $value->product_id;
    //                     $findoffers = DB::table('offers')->where('product_id',$joy['product_id'])->select('bonus','bonus_type','product_id')->first();

    //                     if(in_array($value->product_id,$quen)){
    //                         $quen11 = Helpers::CartProductQuan1($user_id,$value->product_id);
    //                     // dump($quen11);
    //                         $json['related_products'][$r]['product_qty'] = $quen11;
    //                     }else{
    //                         $json['related_products'][$r]['product_qty'] = 0;
    //                     }
    //                     $json['related_products'][$r]['product_id'] = $value->product_id;
    //                     //$json['related_products'][$r]['product_images']= $geturl . 'public/uploads/product_image/' . $value->product_images;
    //                     $new_array = explode('{$}',$value->product_images);
    //                     foreach ($new_array as $val) { 
    //                         $checkdata= DB::table('registerusers')->where('id',$user->id)->value('wishlist');
    //                         $data=json_decode($checkdata);
    //                     $img[0] = $geturl . 'public/uploads/product_image/' . $val;
    //                     }
    //                     $json['related_products'][$r]['product_images']=$img[0];
    //                     $json['related_products'][$r]['title'] = $value->title;
    //                     $json['related_products'][$r]['subtitle'] = $value->subtitle;
    //                     $json['related_products'][$r]['purchase_price'] = $value->purchase_price;
    //                     $json['related_products'][$r]['sale_price'] = $value->sale_price;
    //                     $json['related_products'][$r]['description'] = $value->description;
    //                     $json['related_products'][$r]['quantity'] = $value->quantity;
    //                     $json['related_products'][$r]['discount'] = ($findoffers!="")?strval($findoffers->bonus):"";
    //                     $json['related_products'][$r]['discount_type'] = ($findoffers!="")?"$findoffers->bonus_type":"";
    //                     if(!empty($data)){
    //                         $aa = array_column($data , 'product_id');
    //                         if(in_array($value->product_id,$aa)){
    //                             $json['related_products'][$r]['whislist'] = 1;
    //                         }else{
    //                             $json['related_products'][$r]['whislist'] = 0;
    //                         }
    //                     }else{
    //                         $json['related_products'][$r]['whislist'] = 0;
    //                     }
    //                     $r++;
    //                 }
    //             }else{
    //                 $json['related_products'] = [];
    //             }

    //             $findoffers2 = DB::table('offers')->where('product_id',$getdata->product_id)->select('bonus','bonus_type','product_id')->first();
    //             if(in_array($getdata->product_id,$quen)){
    //                 $quen11 = Helpers::CartProductQuan1($user_id,$getdata->product_id);
    //             // dump($quen11);
    //                 $json['product_qty'] = $quen11;
    //             }else{
    //                 $json['product_qty'] = 0;
    //             }
    //             $json['product_id'] = $getdata->product_id;
    //             // $json['product_images'] = $geturl . 'public/uploads/product_image/' . $getdata->product_images;
    //             $array = explode('{$}',$getdata->product_images);
    //                     foreach ($array as $val) { 
    //                         $checkdata= DB::table('registerusers')->where('id',$user->id)->value('wishlist');
    //                         $data=json_decode($checkdata);
    //                         $json['product_images'][] = $geturl . 'public/uploads/product_image/' . $val;
    //                     }
    //             $json['title'] = $getdata->title;
    //             $json['subtitle'] = $getdata->subtitle;
    //             $json['purchase_price'] = $getdata->purchase_price;
    //             $json['sale_price'] = $getdata->sale_price;
    //             // $json['discount'] = $getdata->discount;
    //             $json['description'] = $getdata->description;
    //             $json['quantity'] = $getdata->quantity;
    //             $json['discount'] = ($findoffers2!="")?strval($findoffers2->bonus):"";
    //             $json['discount_type'] = ($findoffers2!="")?"$findoffers2->bonus_type":"";
    //             if(!empty($data)){
    //                 $aa = array_column($data , 'product_id');
    //                 if(in_array($getdata->product_id,$aa)){
    //                     $json['whislist'] = 1;
    //                 }else{
    //                     $json['whislist'] = 0;
    //                 }
    //             }else{
    //                 $json['whislist'] = 0;
    //             }
    //             return response()->json(array($json));                
    //         }else{
    //             $json['success'] = false;
    //             $json['related_products'] = 0;
    //             $json['message'] = 'Enter Required Field!';
    //             return response()->json($json);
    //         }
    //     }
    // }
    //End
    
    public function singleproduct(Request $Request){
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $user = Helpers::isAuthorize($Request);
        $user_id = $user->id;
        $quen = Helpers::CartProductQuan($user_id);
        $getusername = $Request->get('id');
        $json = array();
        if(!empty($getusername)){
            $getdata = DB::table('products')->where('product_id',$getusername)->first();
            if(!empty($getdata)){
                $getrealtedprod = DB::table('products')->where('product_id','!=',$getusername)->where('category',$getdata->category)->get();
                if(!empty($getrealtedprod->toArray())){
                    $r=0;
                    foreach ($getrealtedprod as $key => $value) {
                        $joy['product_id'] = $value->product_id;
                        $findoffers = DB::table('offers')->where('product_id',$joy['product_id'])->select('bonus','bonus_type','product_id')->first();
                        if(in_array($value->product_id,$quen)){
                            $quen11 = Helpers::CartProductQuan1($user_id,$value->product_id);
                            $json['related_products'][$r]['product_qty'] = $quen11;
                        }else{
                            $json['related_products'][$r]['product_qty'] = 0;
                        }
                        $json['related_products'][$r]['product_id'] = $value->product_id;
                        $new_array = explode('{$}',$value->product_images);
                        foreach ($new_array as $val) { 
                            $checkdata= DB::table('registerusers')->where('id',$user->id)->value('wishlist');
                            $data=json_decode($checkdata);
                            $img[0] = $geturl . 'public/uploads/product_image/' . $val;
                        }
                        $json['related_products'][$r]['product_images']=$img[0];
                        $json['related_products'][$r]['title'] = $value->title;
                        $json['related_products'][$r]['subtitle'] = $value->subtitle;
                        $json['related_products'][$r]['purchase_price'] = $value->purchase_price;
                        $json['related_products'][$r]['sale_price'] = $value->sale_price;
                        $json['related_products'][$r]['description'] = $value->description;
                        $json['related_products'][$r]['quantity'] = $value->quantity;
                        $json['related_products'][$r]['discount'] = ($findoffers!="")?strval($findoffers->bonus):"";
                        $json['related_products'][$r]['discount_type'] = ($findoffers!="")?"$findoffers->bonus_type":"";
                        if(!empty($data)){
                            $aa = array_column($data , 'product_id');
                            if(in_array($value->product_id,$aa)){
                                $json['related_products'][$r]['whislist'] = 1;
                            }else{
                                $json['related_products'][$r]['whislist'] = 0;
                            }
                        }else{
                            $json['related_products'][$r]['whislist'] = 0;
                        }
                        $r++;
                    }
                }else{
                    $json['related_products'] = [];
                }

                $findoffers2 = DB::table('offers')->where('product_id',$getdata->product_id)->select('bonus','bonus_type','product_id')->first();
                if(in_array($getdata->product_id,$quen)){
                    $quen11 = Helpers::CartProductQuan1($user_id,$getdata->product_id);
                    $json['product_qty'] = $quen11;
                }else{
                    $json['product_qty'] = 0;
                }
                $json['product_id'] = $getdata->product_id;
                $array = explode('{$}',$getdata->product_images);
                        foreach ($array as $val) { 
                            $checkdata= DB::table('registerusers')->where('id',$user->id)->value('wishlist');
                            $data=json_decode($checkdata);
                            $ratting = DB::table('product_review')->where('product_id',$getdata->product_id)->where('status',1)->select('ratting')->get();
                            $countproductid = DB::table('product_review')->where('product_id',$getdata->product_id)->where('status',1)->select('product_id')->count(); 
                            //average ratting loop
                            $j = 0;
                            $total =0;
                            $datass= [];
                            foreach($ratting as $rate){
                                    $ratting = DB::table('product_review')->where('product_id',$getdata->product_id)->select('user_name','ratting','review','user_image','date')->get();
                                    
                                    $dd =$ratting[$j];
                                        $datass[] = $dd; 
                                    $total = $total+$ratting[$j]->ratting;
                                    $rattingdata=json_decode($ratting); 
                                    $j++;
                                }
                           //end avearage ratting loop
                            $json['product_images'][] = $geturl . 'public/uploads/product_image/' . $val;
                        }
                $json['title'] = $getdata->title;
                $json['subtitle'] = $getdata->subtitle;
                $json['purchase_price'] = $getdata->purchase_price;
                $json['sale_price'] = $getdata->sale_price;
                $json['description'] = $getdata->description;
                $json['quantity'] = $getdata->quantity;
                $json['discount'] = ($findoffers2!="")?strval($findoffers2->bonus):"";
                $json['discount_type'] = ($findoffers2!="")?"$findoffers2->bonus_type":"";
                $json['reviewdata'] = $datass;
                if($countproductid == 0){
                    $json['ratting'] = 0;
                }else{
                    $avgratting = ($total/$countproductid);
                    $json['ratting'] =$avgratting ;
                }
                if(!empty($data)){
                    $aa = array_column($data , 'product_id');
                    if(in_array($getdata->product_id,$aa)){
                        $json['whislist'] = 1;
                    }else{
                        $json['whislist'] = 0;
                    }
                }else{
                    $json['whislist'] = 0;
                }
                return response()->json(array($json));                
            }else{
                $json['success'] = false;
                $json['related_products'] = 0;
                $json['message'] = 'Enter Required Field!';
                return response()->json($json);
            }
        }
    }
    
    public function categoryproduct(Request $Request)
    {
    Helpers::setHeader(200);
    Helpers::timezone();
    $geturl = Helpers::geturl();
    $user = Helpers::isAuthorize($Request);
    $user_id = $user->id;
    $getusername = $Request->get('category_id');
    $json = array();
    if(!empty($getusername)){
        $getdata = DB::table('products')->where('category',$getusername)->get();
        if(!empty($getdata)){
            $i=0;
            foreach($getdata as $getdatas){
                $json[$i]['product_id'] = $getdatas->product_id;
                $json[$i]['product_images'] = $geturl . 'public/uploads/product_image/' . $getdatas->product_images;
                $json[$i]['title'] = $getdatas->title;
                $json[$i]['subtitle'] = $getdatas->subtitle;
                $json[$i]['purchase_price'] = $getdatas->purchase_price;
                $json[$i]['sale_price'] = $getdatas->sale_price;
                $json[$i]['discount'] = $getdatas->discount;
                $i++;
            }
            return response()->json($json);
        }else{
            $json['success'] = false;
            $json['message'] = 'Enter Required Field!';
            return response()->json($json);
        }
            }
            else{
                $json['success'] = false;
                $json['message'] = 'Invalid Category ID';
                return response()->json($json);
            }
    }

    public function subcategoryproduct(Request $Request)
    {
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $user = Helpers::isAuthorize($Request);
        $user_id = $user->id;
        $quen = Helpers::CartProductQuan($user_id);
        $getusername = [$Request->get('category_id'),$Request->get('subcategory_id')];
        $json = array();
        if(!empty($getusername)){
            $getdata = DB::table('products')->where('category',$getusername[0])
                            ->where('sub_category',$getusername[1])->get();
            if(!empty($getdata)){
                $i=0;
                foreach($getdata as $getdatas){

                    $findoffers = DB::table('offers')->where('product_id',$getdatas->product_id)->select('bonus','bonus_type','product_id')->first();

                    if(!empty($quen)){
                         if(in_array($getdatas->product_id,$quen)){
                            $quen11 = Helpers::CartProductQuan1($user_id,$getdatas->product_id);
                    
                            $json[$i]['product_qty'] = $quen11;
                        }else{
                            $json[$i]['product_qty'] = 0;
                        }
                    }else{
                        $json[$i]['product_qty'] = 0;
                    }

                    $json[$i]['product_id'] = $getdatas->product_id;
                    $array = explode('{$}',$getdatas->product_images);
                     foreach ($array as $value) {
                        $checkdata= DB::table('registerusers')->where('id',$user->id)->value('wishlist');
                        $data=json_decode($checkdata);
                        $image[0] =$geturl . 'public/uploads/product_image/' . $value;
                     }
                     $json[$i]['product_images'] = $image[0];

                  //  $json[$i]['product_images'] = $geturl . 'public/uploads/product_image/' . $getdatas->product_images;
                    $json[$i]['title'] = $getdatas->title;
                    $json[$i]['subtitle'] = $getdatas->subtitle;
                    $json[$i]['purchase_price'] = $getdatas->purchase_price;
                    $json[$i]['sale_price'] = $getdatas->sale_price;
                    // $json[$i]['discount'] = $getdatas->discount;
                    $json[$i]['quantity'] = $getdatas->quantity;
                    $json[$i]['discount'] = ($findoffers!="")?$findoffers->bonus:"";
                    $json[$i]['discount_type'] = ($findoffers!="")?strval($findoffers->bonus_type):"";
                    if(!empty($data)){
                        $aa = array_column($data , 'product_id');
                        if(in_array($getdatas->product_id,$aa)){
                            $json[$i]['whislist'] = 1;
                        }else{
                            $json[$i]['whislist'] = 0;
                        }
                    }else{
                        $json[$i]['whislist'] = 0;
                    }
                    $i++;
                
                }
                return response()->json($json);
            }else{
                $json['success'] = false;
                $json['message'] = 'Enter Required Field!';
                return response()->json($json);
            }
        }
    }


    // public function subcategoryproduct(Request $Request)
    // {
    //     Helpers::setHeader(200);
    //     Helpers::timezone();
    //     $geturl = Helpers::geturl();
    //     $user = Helpers::isAuthorize($Request);
    //     $user_id = $user->id;
    //     $quen = Helpers::CartProductQuan($user_id);
    //     $getusername = [$Request->get('category_id'),$Request->get('subcategory_id')];
    //     $json = array();
    //     if(!empty($getusername)){
    //         $getdata = DB::table('products')->where('category',$getusername[0])
    //         ->where('sub_category',$getusername[1])->get();
    //     // dd($getdata);
    //         if(!empty($getdata)){
    //             $i=0;
    //             foreach($getdata as $getdatas){

    //                 $findoffers = DB::table('offers')->where('product_id',$getdatas->product_id)->select('bonus','bonus_type','product_id')->first();

    //                 if(!empty($quen)){
    //                      if(in_array($getdatas->product_id,$quen)){
    //                         $quen11 = Helpers::CartProductQuan1($user_id,$getdatas->product_id);
                    
    //                         $json[$i]['product_qty'] = $quen11;
    //                     }else{
    //                         $json[$i]['product_qty'] = 0;
    //                     }
    //                 }else{
    //                     $json[$i]['product_qty'] = 0;
    //                 }

    //                 $json[$i]['product_id'] = $getdatas->product_id;
    //                 $array = explode('{$}',$getdatas->product_images);
    //                  foreach ($array as $value) {
    //                     $image[0] =$geturl . 'public/uploads/product_image/' . $value;
    //                  }
    //                  $json[$i]['product_images'] = $image[0];

    //               //  $json[$i]['product_images'] = $geturl . 'public/uploads/product_image/' . $getdatas->product_images;
    //                 $json[$i]['title'] = $getdatas->title;
    //                 $json[$i]['subtitle'] = $getdatas->subtitle;
    //                 $json[$i]['purchase_price'] = $getdatas->purchase_price;
    //                 $json[$i]['sale_price'] = $getdatas->sale_price;
    //                 // $json[$i]['discount'] = $getdatas->discount;
    //                 $json[$i]['quantity'] = $getdatas->quantity;
    //                 $json[$i]['discount'] = ($findoffers!="")?$findoffers->bonus:"";
    //                 $json[$i]['discount_type'] = ($findoffers!="")?strval($findoffers->bonus_type):"";
    //                 $i++;
                
    //             }
    //             return response()->json($json);
    //         }else{
    //             $json['success'] = false;
    //             $json['message'] = 'Enter Required Field!';
    //             return response()->json($json);
    //         }
    //             }
    // }

    public function userdetails(Request $Request)
    {
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $user = Helpers::isAuthorize($Request);
        $user_id = $user->id;
        $json = array();
        if(!empty($user_id)){
            $getdata = DB::table('registerusers')->where('id',$user_id)->get();
        // dd($getdata);
            if(!empty($getdata)){
                $i=0;
                foreach($getdata as $getdatas){
                    $getbalance = DB::table('userbalance')->where('user_id',$getdatas->id)->first();
                    $json[$i]['id'] = $getdatas->id;
                    // $json[$i]['image'] = $geturl . 'public/' . $getdatas->image;
                    $json[$i]['image'] = $getdatas->image;
                    $json[$i]['fullname'] = $getdatas->fullname;
                    $json[$i]['email'] = $getdatas->email;
                    $json[$i]['mobile'] = $getdatas->mobile;
                    $json[$i]['address'] = (json_decode($getdatas->address,true));
                    $json[$i]['city'] = $getdatas->city;
                    $json[$i]['state'] = $getdatas->state;
                    $json[$i]['dob'] = $getdatas->dob;
                    $json[$i]['refer_code'] = ($getdatas->refer_code!="")?$getdatas->refer_code:"";
                    $json[$i]['gender'] = $getdatas->gender;
                    $json[$i]['wallet_balance'] = ($getbalance!="")?$getbalance->balance:"";
                    $json[$i]['coins'] = ($getbalance!="")?$getbalance->coins:"";
                
                }
                return response()->json($json);
            }else{
                $json['success'] = false;
                $json['message'] = 'Enter Required Field!';
                return response()->json($json);
            }
                }
    }
    
    


    public function forgotpassword(Request $request)
    {
        try {
            Helpers::setHeader(200);
            if ($request->isMethod('post')) {
                $username = $request->get('username');
              //  dd($username);
                $newmailaddress = Helpers::getnewmail($username);
                $finddetails = DB::table('registerusers')->where(function ($query) use ($username, $newmailaddress) {
                    $query->where('email', '=', $username);
                    $query->orWhere('email', '=', $newmailaddress);
                })->orWhere('mobile', $username)->first();
                $json = array();
                if (!empty($finddetails)) {
                    if ($finddetails->status == 1) {
                        // $input['code'] = rand(1000, 9999);
                          $input['code'] = 1234;
                        DB::connection('mysql2')->table('registerusers')->where('id', $finddetails->id)->update($input);
                        if ($finddetails->mobile == $username) {
                            $message = $input['code'] . " is the OTP for your " . (Helpers::settings()->project_name ?? '') . " account. NEVER SHARE YOUR OTP WITH ANYONE. " . (Helpers::settings()->project_name ?? '') . " will never call or message to ask for the OTP.";
                            Helpers::sendTextSmsNew($message, $finddetails->mobile);
                            $json['success'] = true;
                            $json['message'] = 'OTP sent on your mobile number.';
                            return response()->json($json);
                        }
                        if ($username == $finddetails->email || $newmailaddress == $finddetails->email) {
                            /* send mail */
                            $emailsubject = 'Reset Password - ' . Helpers::projectName();
                            $datamessage['email'] = $username;
                            $datamessage['subject'] = $emailsubject;
                            $datamessage['content'] = Helpers::mailbody($input['code']);
                            // Helpers::mailSmtpSend($datamessage);
                            /* end code for send mail */
                            $json['success'] = true;
                            $json['message'] = 'We have sent you an OTP on your registered email address. Please check your email and reset your password.';
                            return response()->json($json);
                        }
                    } else {
                        $json['success'] = false;
                        $json['message'] = 'Sorry you cannot reset your password now. Please contact to administrator.';
                        return response()->json($json);
                    }
                } else {
                    $json['success'] = false;
                    $json['message'] = 'You have entered invalid details to reset your password.';
                    return response()->json($json);
                }
            } else {
                $msgg['success'] = false;
                $msgg['message'] = 'Unauthorized request';
                echo json_encode($msgg);
                die;
            }

        } catch (\Exception $e) { 
            Log::info($e->getMessage());
            return response()->json(array(['success' => false, 'message' => $e->getMessage()])); 
        }
    }


    public function changepassword(Request $request)
    {
        Helpers::setHeader(200);
        Helpers::timezone();
        if ($request->isMethod('post')) {
            $input = $request->all();
         
            /* check authentication*/
            $user = Helpers::isAuthorize($request);
            unset($input['auth_key']);
            $getid = $user->id;
            $newpassword = "";
            $oldpassword = $input['oldpassword'];
            $newpassword = $input['newpassword'];
            $confirmpassword = $input['confirmpassword'];
            if ($newpassword == $confirmpassword) {
                $password = $newpassword;
                $findusers = DB::table('registerusers')->where('id', $getid)->select('id', 'password')->first();
                if (!empty($findusers)) {
                    if (Hash::check($oldpassword, $findusers->password)) {
                        $data['password'] =  Hash::make($password);
                        $data['auth_key'] = md5(Hash::make($password));
                        DB::connection('mysql2')->table('registerusers')->where('id', $findusers->id)->update($data);
                        $json['success'] = true;
                        $json['auth_key'] = $data['auth_key'];
                        $json['message'] = 'Password Changed Successfully';
                        return response()->json(array($json));
                    } else {
                        $json['success'] = false;
                        $json['message'] = 'Old password does not matched to previous password.';
                        return response()->json(array($json));
                    }
                } else {
                    $json['success'] = false;
                    $json['message'] = 'password is not exsited in database.';
                    return response()->json(array($json));
                }
            } else {
                $response['success'] = false;
                $response['message'] = 'Confirm password and new not matched';
                return response()->json(array($response));
            }
        } else {
            $msgg['success'] = false;
            $msgg['message'] = 'Unauthorized request';
            echo json_encode(array($msgg));
            die;
        }
    }

    public function featuredProduct(Request $request){
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $user = Helpers::isAuthorize($request);
        $Uid = $user->id;
        $getfeatureProid = DB::table('products')->where('is_featured',1)->get();
        if(!empty($getfeatureProid)){
            $t=0;
            foreach($getfeatureProid as $prods){
                $json[$t]['id'] = $prods->product_id;
                $json[$t]['product_images'] = $geturl . 'public/uploads/product_image/'. $prods->product_images;
                $json[$t]['title'] = $prods->title;
                $json[$t]['subtitle'] = $prods->subtitle;
                $json[$t]['quantity'] = $prods->quantity;
                $json[$t]['purchase_price'] = $prods->purchase_price;
                $json[$t]['sale_price'] = $prods->sale_price;
                $json[$t]['description'] = $prods->description;
                $t++;
            }
            return response()->json($json);
        }else{
            $json['success'] = false;
            $json['message'] = 'Featured Product Not Availlable!';
            return response()->json($json);
        }

    }

        public function requestaddcash(Request $request){
            if ($request->isMethod('post')) {
                    $input = $request->all();
                    $user = Helpers::isAuthorize($request);
                    $Uid =  $userid =  $user->id;
                    unset($input['auth_key']);
                    $getdata['amount'] = $amount = floor($request->get('amount'));
                    $getdata['userid'] = $userid;
                    $getdata['paymentby'] = $request->get('paymentby');
                    // $type = $request->get('type');

                    /* check for the user details */
                    $loginsession = DB::table('registerusers')->where('id', $Uid)->first();
                    if (!empty($loginsession)) {
                        $paymentdata['amount'] = $amount;
                        $paymentdata['userid'] = $loginsession->id;
                        $paymentdata['username'] = $loginsession->username;
                        $paymentdata['mobile'] = $loginsession->mobile;
                        $paymentdata['email'] = $loginsession->email;
                        $paymentdata['paymentby'] = $request->get('paymentby');
                        $paymentprocess['amount'] = $amount;
                        $paymentprocess['userid'] = $loginsession->id;
                        $paymentprocess['paymentmethod'] = $request->get('paymentby');
                        $txnid = (Helpers::settings()->short_name ?? ''). '-add-' . time() . $loginsession->id;
                        $paymentprocess['orderid'] = $txnid;
                        $Json['orderId'] ='';
                        // if($request->get('paymentby') == 'razorpay') {
                        //     include(app_path() . '/razorpay/razorpay-php/Razorpay.php');
                        //     include(app_path() . '/razorpay/config.php');
                        //     $api = new Api($keyId, $keySecret);
                        //     $orderData = [
                        //         'receipt'         => $txnid,
                        //         'amount'          => $amount * 100,
                        //         'currency'        => 'INR',
                        //         'payment_capture' => 1
                        //     ];
                        //     $razorpayOrder = $api->order->create($orderData);
                        //     $razorpayOrderId = $razorpayOrder['id'];
                        //     $Json['orderId'] = $razorpayOrderId;
                        //     $paymentprocess['orderid'] = $razorpayOrderId;
                        // }
                        if($request->get('paymentby')=='paykun'){
                            $Json['orderId'] = time().$loginsession->id;
                        }

                        DB::connection('mysql2')->table('paymentprocess')->insert($paymentprocess);
                        $Json['success'] = true;
                        $Json['txnid'] = $txnid;
                            LOG::info($Json);
                        return response()->json($Json);
                    } else {
                        $Json['success'] = false;
                        $Json['txnid'] = 0;
                        return response()->json($Json);
                    }
            }else{
                $Json['message'] = 'Invalid Method';
                $Json['success'] = false;
                $Json['txnid'] = 0;
                return response()->json($Json);
            }
        }

        public function mytransaction (Request $request){
            $user = Helpers::setHeader(200);
            $user = Helpers::isAuthorize($request);
            $Uid =  $userid =  $user->id;
            $findlastow = DB::table('transactions')
                        ->join('registerusers', 'registerusers.id', 'transactions.userid')
                        ->orderBy('transactions.id', 'DESC')
                        ->where('transactions.userid', $Uid)
                        ->select('registerusers.team', 'transactions.*')
                        ->get();
            $Json = array();
            $i = 0;
            if (!empty($findlastow)) {
                foreach ($findlastow as $val) {
                    $Json[$i]['id'] = $val->id;
                    $Json[$i]['userid'] = $val->userid;
                    $Json[$i]['type'] = $val->type;
                    $Json[$i]['amount'] = $val->amount;
                    $Json[$i]['status'] = 1;
                    $Json[$i]['success'] = true;
                    $Json[$i]['date_time'] = date('d M Y H:i', strtotime($val->created_at));
                    $Json[$i]['username'] = $val->team;
                    $Json[$i]['txnid'] = $val->transaction_id;
                    $Json[$i]['paymentstatus'] = $val->paymentstatus;
                    $i++;
                }
            } else {
                $Json['success'] = false;
                $Json['message'] = 'No transaction available';
            }
            return response()->json($Json);
        }

        public function createFeedback (Request $request){
            if ($request->isMethod('post')) {
                Helpers::setHeader(200);
                $user = Helpers::isAuthorize($request);
                $Uid = $user->id;
                $input = $request->all();
                $Json = array();
                $getfeedback = DB::table('feedback')->where('userid',$Uid)->first();
                if(empty($getfeedback)){              
                    $data['userid'] = $Uid;
                    $data['review'] = $input['description'];
                    $data['title'] = $input['title'];
                        
                    DB::table('feedback')->insert($data);
                    
                    $Json['success'] = true;
                    $Json['message'] = "Feedback Given Successfully!";
                    return response()->json(array($Json));
                }else{
                    $Json['successs'] = false;
                    $Json['message'] = "Already given feedback!";
                    return response()->json(array($Json));
                }
            }else{
                $Json['message'] = 'Invalid Method';
                $Json['success'] = false;
                $Json['txnid'] = 0;
                return response()->json($Json);                
            }
        }

        public function userFeedback (Request $request){
            Helpers::setHeader(200);
            $user = Helpers::isAuthorize($request);
            $Uid = $user->id;
            $Json = array();
            $getfeedback = DB::table('feedback')->where('userid',$Uid)->get();
            if(!empty($getfeedback)){
                $k=0;
                foreach($getfeedback as $feedbacks){
                    $Json[$k]['id'] = $feedbacks->id;
                    $Json[$k]['userid'] = $feedbacks->userid;
                    $Json[$k]['review'] = $feedbacks->review;
                    $Json[$k]['title'] = $feedbacks->title;
                    $Json[$k]['name'] = $feedbacks->name;
                    $Json[$k]['email'] = $feedbacks->email;
                    $k++;
                }
                return response()->json($Json);
            }else{
                $Json['successs'] = fallse;
                $Json['message'] = "Not Data Yet!";
                return response()->json($Json);
            }
        }

        public function add_address(Request $request)
        {
             Helpers::setHeader(200);
             Helpers::timezone();
             $user = Helpers::isAuthorize($request);
             $geturl = Helpers::geturl();
             $id = $user->id;
             $data = $request->all();

             $validator = Validator::make($data, [
                 'fname' => 'required',
                 'lname' => 'required',
                 'email' => 'required|email|unique:users,email',
                 'country' => 'required',
                 'address' => 'required',
                 'city' => 'required',
                 'zipcode'  => 'required',
                 'phone_no' => 'required|numeric|digits:10'
                
             ]);
             if ($validator->fails()) {
                 $error = $this->validationHandle($validator->messages());
                 return response()->json(array(['success' => false, 'message' => $error]));
             }
             else{
                $add = $data['address'];
                $loc = $this->getlocation($add);
                $latitude =$newaddress['latitude'] =$loc['results'][0]['geometry']['location']['lat'];
                $longitude =$newaddress['longitude'] =$loc['results'][0]['geometry']['location']['lng'];
                $data['latitude']=$latitude;
                $data['longitude']=$longitude;
                $demo =json_encode($data);
                 $data = DB::table('registerusers')->where('id', $id)->update(array('address' => $demo));
                 $data = DB::table('registerusers')->where('id', $id)->update(array('default_address' => $demo));
                 return response()->json(array(['status'=>'success','msg'=>'All field are successfully added in the database']));
                //$data = DB::table('registerusers')->where('address', $address)->insert();
                //dd($data);
             }

        }

        public function view_address(Request $request){
            Helpers::setHeader(200);
            Helpers::timezone();
            $user = Helpers::isAuthorize($request);
            $id = $user->id;
            if(!empty($id)){
             
                $data = DB::table('registerusers')->where('id', $id)->select('address')->get();
                $datas =(json_decode($data[0]->address,true));
              //  $test=array_column($data,'address'); 
                  // dd($datas);
                return response()->json(array(['status'=>true,'msg'=>'Users Address','data'=>$datas]));

            } else{
               
                //     $data = DB::table('registerusers')->where('id', $id)->update(array('address' => $demo));
                //  $data = DB::table('registerusers')->where('id', $id)->update(array('default_address' => $demo));
                 return response()->json(array(['status'=>false,'msg'=>'address not found ']));
                }
        }

        public function matchCodeForReset(Request $request)
        {
            try{
                Helpers::setHeader(200);
                if ($request->isMethod('post')) {
                    $input = $request->all();
                    /* check authentication*/
                    $username = $request->get('username');
                    $username = Helpers::getnewmail($username);
               
                    $code = $request->get('code');
                  //  dump($code);
                    $findlogin = DB::table('registerusers')->where(function ($query) use ($username) {
                        $query->where('mobile', '=', $username);
                        $query->orwhere('email', '=', $username);
                    })->where('code', $code)->first();
                 // dd($findlogin);
                    if (!empty($findlogin)) {
                        
                        $json['success'] = true;
                        $json['token'] = Crypt::encrypt($findlogin->id);
                        $json['message'] = 'Otp matched.';
                        return response()->json(array($json));
                        die;
                    } else {
                        $json['success'] = false;
                        $json['token'] = 0;
                        $json['message'] = 'Invalid OTP.';
                        return response()->json(array($json));
                        die;
                    }
                } else {
                    $msgg['success'] = false;
                    $msgg['message'] = 'Unauthorized request';
                    echo json_encode($msgg);
                    die;
                }

            } catch (\Exception $e) { 
                Log::info($e->getMessage());
                return response()->json(array(['success' => false, 'message' => $e->getMessage()])); 
            }
        }

        public function editprofile(Request $request)
        {

            $geturl = Helpers::geturl();
            Helpers::timezone();
            Helpers::setHeader(200);
            if ($request->isMethod('post')){
                $input = $request->all();
                $user = Helpers::isAuthorize($request);
                $id = $user->id;
                if(!empty($input['fullname'])){
                  DB::table('registerusers')->where('id',$id)->update(array('fullname'=>$input['fullname']));
                    response()->json(array(['status'=>true,'msg'=>'Name is successfully Edit']));
                     }else{
                        return    response()->json(array(['status'=>true,'msg'=>'fullname  is empty']));
               }


                if (!empty($input['mobile'])){
                    $chake =  DB::table('registerusers')->where('id',$id)->where('mobile', $input['mobile'])->get();
                }
            if($chake->isEmpty()){
                    
                 $kk= DB::table('registerusers')->where('mobile', $input['mobile'])->get();

                if($kk->isEmpty()){

                    $input['code'] = 1234;
                    $message = $input['code'] . " is your OTP for tokri. We never ask for OTP over phone calls or messages. Please don't share this OTP with anyone.";
                    // Helpers::sendTextSmsNew($message, $input['mobile']);
                    DB::table('registerusers')->where('id', $id)->update(array('code'=>$input['code']));
                    return  response()->json(array(['status'=>true,'msg'=>'otp send to your  mobile number']));
            }else{

                 return  response()->json(array(['status'=>true,'msg'=>'number is all ready exists']));
            }
            
            }else{
               return response()->json(array(['status'=>true,'msg'=>'Name is successfully Edit']));

            }


            }
        }

        public function editprofileotp(Request $request){
            Helpers::setHeader(200);
            if ($request->isMethod('post')) {
                $input = $request->all();
                /* check authentication*/
                $user = Helpers::isAuthorize($request);
                $id = $user->id;
                $usermobile = $request->get('mobile');
                // dd($usermobile);
                if(!empty($usermobile)){
                    $val=  DB::table('registerusers')->where('mobile',$usermobile)->first();
                    if(!empty($val)){
                        $msgg['success'] = true;
                        $msgg['message'] = 'Mobile number is all ready exists';
                        echo json_encode($msgg);
                        die;
                    }

                }

                $code = $request->get('code');
                $findlogin = DB::table('registerusers')->where('id',$id)->where('code', $code)->first();
                    //  dd($findlogin);
                if (!empty($findlogin)) {
                    DB::table('registerusers')->where('id',$id)->update(array('mobile'=>$usermobile,'code'=>0));
                    $json['success'] = true;
                    //$json['token'] = Crypt::encrypt($findlogin->id);
                    $json['message'] = 'Otp matched. mobile number  change sucessfully ';
                    return response()->json(array($json));
                    die;
                } else {
                    $json['success'] = false;
                   // $json['token'] = 0;
                    $json['message'] = 'Invalid OTP.';
                    return response()->json(array($json));
                    die;
                }
            } else {
                $msgg['success'] = false;
                $msgg['message'] = 'Unauthorized request';
                echo json_encode($msgg);
                die;
            }
               
        }

        public function resetpassword(Request $request)
            {
                Helpers::setHeader(200);
                if ($request->isMethod('post')) {
                    $input = $request->all();
                    $gettoken = Crypt::decrypt($request->get('token'));
                    //dump($gettoken);
                    $password = $request->get('password');
                   // dump($password);
                    $data['code'] = $request->get('code');
                   // dump($data);
                    $findloginforcode = DB::table('registerusers')->where('id', $gettoken)->where('code', $request->get('code'))->first();
                    // dd($findloginforcode);
                    if (!empty($findloginforcode)) {
                        $data['code'] = 0;
                        $data['password'] =  Hash::make($password);
                        $data['auth_key'] = md5(Hash::make($password));
                        $findlogin = DB::connection('mysql2')->table('registerusers')->where('id', $gettoken)->update($data);
                        $json['success'] = true;
                        $json['message'] = 'Change password successfully';
                        return response()->json(array($json));
                    } else {
                        $json['success'] = false;
                        $json['message'] = 'Invalid token';
                        return response()->json(array($json));
                    }
                } else {
                    $msgg['success'] = false;
                    $msgg['message'] = 'Unauthorized request';
                    echo json_encode($msgg);
                    die;
                }
        }


        public function getlocation($add){
            // dd($add);
            ///////////find location
            $addres = $add; // Google HQ
            $prepAddr = str_replace(' ','+',$addres);
            $api_key = 'AIzaSyCRzByDjNttORvQ31CJD1H8d2LTc3SHlt4';
            $geocode= 'https://maps.googleapis.com/maps/api/geocode/json?address='.$prepAddr.'&key=AIzaSyCRzByDjNttORvQ31CJD1H8d2LTc3SHlt4';
            
            $curl = curl_init($geocode);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            $result = curl_exec($curl);
            curl_close($curl);
            $details = json_decode($result,true);
            return $details;
        //  dd($details);
            //--------------------------------------------------------------------------------
    }

    
    public function wishlist(Request $request){
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $user = Helpers::isAuthorize($request);
        $input = $request->all();
        $validator = Validator::make($input, [
        'product_id' => 'required',
        ]);
        if ($validator->fails()){
            $error = $this->validationHandle($validator->messages());
            return response()->json(array(['success' => false, 'message' => $error]));
        }else{
            $test=DB::table('products')->where('product_id',$input['product_id'])->first();
            if(!empty($test)){
                $checkdata= DB::table('registerusers')->where('id',$user->id)->value('wishlist');
                if($checkdata == ""){
                    $data = json_encode(array($input));
                    DB::table('registerusers')->where('id',$user->id)->update(['wishlist'=>$data]);
                    return response()->json(array(['success' => true, 'message' => 'Add to wishlist successfully']));
                }else{
                    $value= DB::table('registerusers')->where('id',$user->id)->value('wishlist');
                    $do=json_decode($value);
                    $searhproduct=strval(array_search($input['product_id'],array_column($do,'product_id')));
                    if($searhproduct==""){
                        $product = $input;
                        $input=array_push($do,$product);
                        $decode_data = json_encode($do);
                        DB::table('registerusers')->where('id',$user->id)->update(['wishlist'=>$decode_data]);
                        return response()->json(array(['success' => true, 'message' => 'Add to wishlist successfully']));
                    }else{
                        $itemdata = collect($do)->forget($searhproduct);
                        $decode_data = json_encode(array_values($itemdata->toArray()));
                        // $decode_data = json_encode($itemdata);
                        DB::table('registerusers')->where('id',$user->id)->update(['wishlist'=>$decode_data]);
                        return response()->json(array(['success' => true, 'message' => 'Remove from wishlist successfully']));
                    }            
                }
            }else{
                return response()->json(array(['success' => false, 'message' => 'This product id not exited']));
            }
        }
    
    }

    public function viewwishlist(Request $request){
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $user = Helpers::isAuthorize($request);
        $checkdata= DB::table('registerusers')->where('id',$user->id)->value('wishlist');
        if($checkdata == ""){
            $json['success'] = true;
            $json['message'] = 'No Product Add in Cart  Add Some Product First';
            $json['data'] = [];
            return response()->json(array($json,));

        }else{       
            if($checkdata != "[]"){
                $data=json_decode($checkdata);
                $searhproduct=array_column($data,'product_id');
                $i = 0;
                $userdata=[];
                foreach($searhproduct as $pro){
                $productdata = DB::table('products')->where('product_id',$pro)->first();
                $productoffers = DB::table('offers')->where('product_id',$pro)->first();
                if($productoffers == ''){
                    $userdata[$i]['discount'] = ""  ;
                    $userdata[$i]['discount_type'] = "";
                }else{
                    $userdata[$i]['discount'] = $productoffers->bonus  ;
                    $userdata[$i]['discount_type'] = $productoffers->bonus_type;
                }
                $array = explode('{$}',$productdata->product_images);
                        foreach ($array as $value) {
                            $image[0] =$geturl . 'public/uploads/product_image/' . $value;
                        }
                $userdata[$i]['product_id'] =$productdata->product_id ;
                $userdata[$i]['title'] = $productdata->title;
                $userdata[$i]['subtitle'] = $productdata->subtitle;
                $userdata[$i]['description'] = $productdata->description;
                $userdata[$i]['quantity'] = $productdata->quantity;
                $userdata[$i]['product_images']= $image[0];
                // $userdata[$i]['product_images'] =$geturl.'public/uploads/product_image/'.$productdata->product_images;
                $userdata[$i]['purchase_price'] = $productdata->purchase_price;
                $userdata[$i]['sale_price'] = $productdata->sale_price;
                $i++;
                }
                $json['success'] = true;
                $json['message'] = 'All Product Of wishlist';
                $json['data'] = $userdata;
                return response()->json(array($json,));
            }else{
                $json['success'] = true;
                $json['message'] = 'No Product Add in Cart  Add Some Product First';
                $json['data'] = [];
                return response()->json(array($json,));
            }
        }

    }

    // public function viewwishlist(Request $request){
    //     Helpers::setHeader(200);
    //     Helpers::timezone();
    //     $geturl = Helpers::geturl();
    //     $user = Helpers::isAuthorize($request);
    //     $checkdata= DB::table('registerusers')->where('id',$user->id)->value('wishlist');
    //     if($checkdata != "[]"){
    //         $data=json_decode($checkdata);
    //         $searhproduct=array_column($data,'product_id');
    //         $i = 0;
    //         $userdata=[];
    //         foreach($searhproduct as $pro){
    //         $productdata = DB::table('products')->where('product_id',$pro)->first();
    //         $productoffers = DB::table('offers')->where('product_id',$pro)->first();
    //         if($productoffers == ''){
    //             $userdata[$i]['discount'] = ""  ;
    //             $userdata[$i]['discount_type'] = "";
    //         }else{
    //             $userdata[$i]['discount'] = $productoffers->bonus  ;
    //             $userdata[$i]['discount_type'] = $productoffers->bonus_type;
    //         }

    //         $array = explode('{$}',$productdata->product_images);
    //         foreach ($array as $value) {
    //             $image[0] =$geturl . 'public/uploads/product_image/' . $value;
    //         }
    //         $userdata[$i]['product_id'] =$productdata->product_id ;
    //         $userdata[$i]['title'] = $productdata->title;
    //         $userdata[$i]['subtitle'] = $productdata->subtitle;
    //         $userdata[$i]['description'] = $productdata->description;
    //         $userdata[$i]['quantity'] = $productdata->quantity;
    //         $userdata[$i]['product_images']= $image[0];

    //         // $userdata[$i]['product_images']=$geturl . 'public/uploads/product_image/' .  $productdata->product_images;
    //         $userdata[$i]['purchase_price'] = $productdata->purchase_price;
    //         $userdata[$i]['sale_price'] = $productdata->sale_price;
    //         $i++;
    //         }
    //         $json['success'] = true;
    //         $json['message'] = 'All Product Of wishlist';
    //         $json['data'] = $userdata;
    //          return response()->json(array($json,));
    //     }else{
    //         $json['success'] = true;
    //         $json['message'] = 'No Product Add in Cart  Add Some Product First';
    //         $json['data'] = [];
    //         return response()->json(array($json,));
    //     }

    // }


    // public function review(Request $request){
    //     Helpers::setHeader(200);
    //     Helpers::timezone();
    //     $geturl = Helpers::geturl();
    //     $user = Helpers::isAuthorize($request);
    //     $user_id = $user->id;
       
    //     $input = $request->all();
    //     $validator = Validator::make($input, [
    //         'ratting' => 'required',
    //         'product_id'=> 'required',
    //     ]);  
    //     if ($validator->fails()){   
    //         $error = $this->validationHandle($validator->messages());
    //         return response()->json(array(['success' => false, 'message' => $error]));
    //     }else{        
    //         $productdata = DB::table('products')->where('product_id',$input['product_id'])->first();
    //         $checkreview = DB::table('product_review')->where('userid',$user_id)->where('product_id',$productdata->product_id)->first();
    //         if(!empty($productdata)){
    //             if(empty($checkreview)){
    //                 $json['userid'] = $user->id;
    //                 $json['user_name'] = $user-> fullname;
    //                 $json['user_email'] = $user-> email;
    //                 $json['product_id'] = $productdata->product_id;
    //                 $json['product_name'] = $productdata->title;
    //                 $json['ratting'] =  $input['ratting'];
    //                 $json['product_price'] = $productdata->amount; 
    //                 if(!empty($input['ratting'])){
    //                     $json['review'] = "";
    //                 }else{
    //                     $json['review'] = $input['review'];
    //                 }      
    //                 DB::table('product_review')->insert($json);
    //                 return response()->json(array(['success' => true, 'message' => 'your review is successfully added']));
    //             }else{
    //                 return response()->json(array(['success' => false, 'message' => 'You are all ready given review']));
    //             }
    //         }else{
    //             return response()->json(array(['success' => false, 'message' => 'product_id does not exite']));
    //         }
    //     } 
    // }

    // Newupdate
    public function review(Request $request){
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $user = Helpers::isAuthorize($request);
        $user_id = $user->id;
        //   dd($user->image);
        // $date=Carbon::now();
        
        $input = $request->all();
        $validator = Validator::make($input, [
            'ratting' => 'required',
            'product_id'=> 'required',
        ]);  
        if ($validator->fails()){   
            $error = $this->validationHandle($validator->messages());
            return response()->json(array(['success' => false, 'message' => $error]));
        }else{
            $productdata =  DB::table('products')->where('product_id',$input['product_id'])->first();
            if($productdata == ""){
                return response()->json(array(['success' => true, 'message' => 'NO such Product_id found ']));
            }else{
                $checkreview = DB::table('product_review')->where('userid',$user_id)->where('product_id',$productdata->product_id)->first();
                if(!empty($productdata)){
                    if(empty($checkreview)){
                        $json['userid'] = $user->id;
                        $json['user_name'] = $user-> fullname;
                        $json['user_email'] = $user-> email;
                        $json['user_image'] = $user-> image;
                        $json['date'] = Carbon::now();
                        $json['product_id'] = $productdata->product_id;
                        $json['product_name'] = $productdata->title;
                        $json['ratting'] =  $input['ratting'];
                        $json['status'] = 0;
                        $json['product_price'] = $productdata->amount; 
                        if(!empty($input['review'])){
                            $json['review'] = $input['review'];
                        }else{
                            $json['review'] = "";
                        }  
                        
                        DB::table('product_review')->insert($json);
                        return response()->json(array(['success' => true, 'message' => 'your review is successfully added']));
                    }else{
                        return response()->json(array(['success' => false, 'message' => 'You are all ready given review']));
                    }
                }else{
                    return response()->json(array(['success' => false, 'message' => 'product_id does not exite']));
                }
            }    
        }       
    }


    public function imageUploadUser(Request $request){
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $input = $request->all();
        LOG::info($input);
        $user = Helpers::isAuthorize($request);
        $id = $user->id;
        $data = [];
        unset($input['auth_key']);
        if(!empty($input['image'])){
            $imageName = 'img-'.rand(1000,9999).''.time().'.jpg';
            $imsrc = base64_decode($request->get('image'));
            file_put_contents('./public/uploads/user-profile/'.$imageName, $imsrc);
            $data['image'] = $geturl.'public/uploads/user-profile/'.$imageName;
        }else{
            return response()->json(array(['success' => false, 'message' => 'Enter image URL first']));
        }
        LOG::info($data);          
        DB::table('registerusers')->where('id', $id)->update($data);
        $msgg['url'] =  $data['image'];
        $msgg['success'] = true;
        $msgg['message'] = 'Your profile has been updated successfully.';
        return response()->json(array($msgg));
}


}