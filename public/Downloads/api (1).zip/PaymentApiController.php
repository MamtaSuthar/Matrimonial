<?php

namespace App\Http\Controllers\api;

use DB;
use Session;
use bcrypt;
use Config;
use Redirect;
use App\Helpers\Helpers;
use Hash;
use Mail;
use Cache;
use Crypt;

use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests;
// use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use CfPayout;
use Dotenv\Result\Success;
use Validator;
use Razorpay\Api\Api;
// use Helpers;
use Log;
use Razorpay\Api\Order;

use function PHPSTORM_META\type;

class PaymentApiController extends Controller
{

public function paynet(Request $request){


    Helpers::setHeader(200);
    Helpers::timezone();
    $geturl = Helpers::geturl();
    $user = Helpers::isAuthorize($request);
        $input = $request->all();
        
      //dd($input);
        if( !empty($input) ) {

            $data['payment_data'] = json_encode($input);
            // dd(json_decode( $data['payment_data']));
            // dd($data);

            // $lastid = DB::connection('mysql2')->table('razorpay_webhook')->insertGetId($data);
            // $datas = DB::table('razorpay_webhook')->where('id',$lastid)->first();
            $datas =  DB::table('razorpay_webhook')->insert($data);
           // dd($datas);

        }



}

   
   public function verifypayment(Request $request){         
    Helpers::setHeader(200);
    Helpers::timezone();
    $geturl = Helpers::geturl();
    $user = Helpers::isAuthorize($request);
    $user_id =  $user->id;
   // dd($user_id);
        $data = $request->all();
        //dd($data);
        $type = $data['status'];
        $payid = $data['razorpay_payment_id'];
        $orderid = $data['razorpay_order_id'];
      //  dd($type);
       $demo =json_encode($data);
      //  dd($demo);
      //  dd($demo->('razorpay_payment_id'));
     // dd  ($data['razorpay_payment_id']);

        $validator = Validator::make($data, [
            'razorpay_payment_id' => 'required',
            'razorpay_order_id' => 'required',
            'razorpay_signature' => 'required',
            'status'=> 'required',
           
        ]);

        if ($validator->fails()) {
            $error = $this->validationHandle($validator->messages());
            return response()->json(array(['success' => false, 'msg' => $error]));
        }
        else{
            $order['payment_status'] = $type;
            $order['payment_id'] = $payid;

       //  dd($order['payment_status']);
         if($order['payment_status'] == "success"){
             DB::table('orders')->where('user_id', $user_id)->update(array('payment_id' => $order['payment_id'] ,'payment_status' =>$order['payment_status']  ));
             DB::table('paymentprocess')->where('userid', $user_id)->update(array('status' =>$order['payment_status']));
             DB::table('transactions')->where('userid', $user_id)->update(array('paymentstatus' =>$order['payment_status']));
        
            return response()->json(array(['status'=>true,'msg'=>'verifypayment successfully','order_id'=>$orderid]));
         }else{
            return response()->json(array(['status'=>false,'msg'=>'verifypayment is not successful']));
             
         }
         
        }
   


   }



}    