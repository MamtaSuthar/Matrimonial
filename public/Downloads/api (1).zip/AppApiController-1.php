<?php

namespace App\Http\Controllers\api;

use DB;
use Session;
use bcrypt;
use Config;
use Redirect;
use App\Helpers\Helpers;
use Hash;
use Mail;
use Cache;
use Crypt;

use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests;
// use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use CfPayout;
use Validator;
use Razorpay\Api\Api;
// use Helpers;
use Log;

class AppApiController extends Controller
{
public function tempregisteruser(request $request)
    {
        try {
            Helpers::setHeader(200);
            Helpers::timezone();
            $geturl = Helpers::geturl();
            $input = $request->all();
            $validator = Validator::make($input, [
                'fullname' => 'required|min:4',
                'email' => 'required|unique:registerusers|email',
                'password' => 'required|min:4|max:45',
                'mobile' => 'required|numeric|unique:registerusers|digits:10',
            ]);
            // dd('fggf');

            if ($validator->fails()) {
              
                $error = $this->validationHandle($validator->messages());
                return response()->json(array(['success' => false, 'message' => $error]));
            } else {
                // $input['code'] = rand(1000, 9999);
                $input['code'] = 1234;
                $datau['code'] = $input['code'];
                $datau['fullname'] = $input['fullname'];
                $datau['email'] = $input['email'];
                $datau['mobile'] = $input['mobile'];
                $datau['password'] = Hash::make($input['password']);
                $datau['auth_key'] = md5(Hash::make($input['password']));
                if ($request->get('refercode')) {
                    /* check in the register users table */
                    $checkrefercode = DB::table('registerusers')->where('refer_code', $request->get('refercode'))->select('id')->first();
                    if (empty($checkrefercode)) {
                        $json['success'] = false;
                        $json['message'] = 'The entered referred code is not valid. Please enter some valid refer code.';
                        return response()->json(array($json));
                        die;
                    } else {
                        $datau['refer_id'] = $checkrefercode->id;
                    }
                }
                
                $insertid = DB::connection('mysql2')->table('tempuser')->insertGetId($datau);

                $findlogin = DB::table('tempuser')->whereId($insertid)->first();

                // $message = "Your OTP is ".$input['code']." \r\n";
                $message = $input['code'] . " is your OTP for MyPlayerzz11. We never ask for OTP over phone calls or messages. Please don't share this OTP with anyone.";
                // Helpers::sendTextSmsNew($message, $input['mobile']);
                $json['success'] = true;
                $json['message'] = 'OTP sent';
                $json['tempuser'] = base64_encode($insertid);
                // dd($json['tempuser']);
                return response()->json(array($json));
            }
        } catch (\Exception $e) {
            // dd($e);
            return response()->json(array(['success' => false, 'message' => $e->getMessage()]));
        }
    }



    public function registerusers(request $request)
    {
        try {
            Helpers::setHeader(200);
            Helpers::timezone();
            $geturl = Helpers::geturl();
            $formdata = $request->all();
            $validator = Validator::make($formdata, [
                'tempuser' => 'required',
                'otp' => 'required|min:4',
            ]);
            if ($validator->fails()) {
                $error = $this->validationHandle($validator->messages());
                return response()->json(array(['success' => false, 'message' => $error]));
            } else {
                $gid = $request->get('tempuser');
                 $tempid = base64_decode($gid);
                // $tempid = $gid;
            
                $code = $request->get('otp');
               
                $findifuser = DB::table('tempuser')->where('id', $tempid)->where('code', $code)->first();
                // dd($findifuser);
               
                if (empty($findifuser)) {
                    $json['success'] = false;
                    $json['message'] = 'Invalid OTP';
                    return response()->json(array($json));
                    die;
                } else {
                    $input['email'] = $findifuser->email;
                    $input['mobile'] = $getnumber = $findifuser->mobile;
                    $user_verify['mobile_verify'] = 1;
                    $input['password'] = $findifuser->password;
                    $input['auth_key'] = $findifuser->auth_key;
                    $input['refer_id'] = $findifuser->refer_id;
                    $input['status'] = 'activated';
                    $input['code'] = '';
                    $ff = DB::table('registerusers')->where('email', $findifuser->email)
                        ->where('mobile', $findifuser->mobile)->first();
                      
                    if (empty($ff)) {
                        $getinsertid = DB::connection('mysql2')->table('registerusers')->insertGetId($input);
                        // $this->levelincome($getinsertid);
                        $user_verify['userid'] = $getinsertid;
                        DB::connection('mysql2')->table('user_verify')->insert($user_verify);
                        if ($request->get('appid')) {
                            $finusers = DB::table('registerusers')->where('id', $getinsertid)->select('id')->first();
                            DB::connection('mysql2')->table('androidappid')->where('user_id', $getinsertid)->delete();
                            $this->insertAppId($finusers, $request->get('appid'));
                        }
                        $bonustype = 'mobile';
                        $this->registerprocess($request, $getinsertid, $bonustype);
                        DB::connection('mysql2')->table('tempuser')->where('id', $findifuser->id)->delete();
                    }

                    

                    /* delete from temp users */
                    $json['success'] = true;
                    $json['userid'] = $input['auth_key'];
                    $json['auth_key'] = $input['auth_key'];
                    $json['message'] = 'Registration Done';
                    return response()->json(array($json));
                }
            }
        } catch (\Exception $e) {
            return response()->json(array(['success' => false, 'message' => $e->getMessage()]));
        }
    }


    public function loginuser(request $request)
    {
        try {
            Helpers::setHeader(200);
            Helpers::timezone();
            $geturl = Helpers::geturl();
            $formdata = $request->all();
            $validator = Validator::make($formdata, [
                'username'             => 'required', 
                'password'          => 'required|min:4',
            ]);
            if ($validator->fails()){
                $error = $this->validationHandle($validator->messages());
                return response()->json(array(['success' => false,'auth_key' => 0,'userid' => 0, 'message' => $error,])); 
            }else{
                $username = $request->get('username');
                $password = $request->get('password');
                $newmailaddress = Helpers::getnewmail($username);
                $findlogin = DB::table('registerusers')
                ->where(function ($query) use ($username, $newmailaddress) {
                    $query->where('email', '=', $username);
                    $query->orWhere('mobile', '=', $username);
                    $query->orwhere('email', '=', $newmailaddress);
                })->first();
                if (!empty($findlogin)) {
                    if (Hash::check($password, $findlogin->password)) {
                        if ($findlogin->status == 'activated') {
                            if ($request->get('appid')) {
                                DB::connection('mysql2')->table('androidappid')->where('user_id',$findlogin->id)->delete();
                                $this->insertAppId($findlogin, $request->get('appid'));
                            }
                            $userd = $findlogin->id . time() . rand(1000, 9999);
                            $authkey = md5(Hash::make($userd));
                            $userdata['auth_key'] = $authkey;
                            DB::connection('mysql2')->table('registerusers')->where('id', $findlogin->id)->update($userdata);
                            $json['success'] = true;
                            $json['auth_key'] = $authkey;
                            $json['userid'] = $authkey;
                            $json['type'] = 'user';
                            $json['message'] = 'login successfully';
                            return response()->json(array($json));
                        } else {
                            $json['success'] = false;
                            $json['auth_key'] = 0;
                            $json['userid'] = 0;
                            $json['message'] = 'You cannot login now in this account. Please contact to administartor.';
                            return response()->json(array($json));
                        }
                    } else {
                        $json['success'] = false;
                        $json['auth_key'] = 0;
                        $json['userid'] = 0;
                        $json['message'] = 'Invalid username or Password.';
                        return response()->json(array($json));
                    }
                }else{
                    $json['success'] = false;
                    $json['auth_key'] = 0;
                    $json['userid'] = 0;
                    $json['message'] = 'Invalid username or Password.';
                    return response()->json(array($json));
                }
            }
        } catch (\Exception $e) { 
            Log::info($e->getMessage());
            return response()->json(array(['success' => false,'auth_key' => 0,'userid' => 0, 'message' => $e->getMessage()])); 
        }
    }


    public function resendotp(Request $request)
    {
        Helpers::setHeader(200);
        // if($request->isMethod('post')){
        if ($request->get('tempuser')) {
            $gid = $request->get('tempuser');
            $id = unserialize(base64_decode($gid));
            $checkdata = DB::table('tempuser')->where('id', $id)->first();
            if (!empty($checkdata)) {
                $code = $checkdata->code;
                $mobile = $checkdata->mobile;
                $message = $code . " is the OTP for your " . (Helpers::settings()->project_name ?? '') . " account. NEVER SHARE YOUR OTP WITH ANYONE. " . (Helpers::settings()->project_name ?? '') . " will never call or message to ask for the OTP.";

                Helpers::sendTextSmsNew($message, $mobile);

                $json['success'] = true;
                $json['message'] = 'OTP Send';
                return response()->json(array($json));
                die;
            } else {
                $json['success'] = false;
                $json['message'] = 'Invalid id provide';
                return response()->json(array($json));
                die;
            }
        }
        if ($request->get('mobile')) {
            $mobile = $request->get('mobile');
            $checkdata1 = DB::table('registerusers')->where('mobile', $mobile)->first();
            if (!empty($checkdata1)) {
                $code1 = $checkdata1->code;
                $mobile1 = $checkdata1->mobile;
                $message1 = $code1 . "  is the OTP for your " . (Helpers::settings()->project_name ?? '') . " account. NEVER SHARE YOUR OTP WITH ANYONE. " . (Helpers::settings()->project_name ?? '') . " will never call or message to ask for the OTP.";
                Helpers::sendTextSmsNew($message1, $mobile1);
                $json['success'] = true;
                $json['message'] = 'OTP Send';
                return response()->json(array($json));
                die;
            } else {
                $json['success'] = false;
                $json['message'] = 'Invalid id provide';
                return response()->json(array($json));
                die;
            }
        }
        if ($request->get('email')) {
            $email = $request->get('email');
            $checkdata1 = DB::table('registerusers')->where('email', $email)->first();
            if (!empty($checkdata1)) {
                $emailsubject = 'Activate Account - ' . Helpers::settings()->project_name ?? '';
                $content = '<tr>
                        <td style="padding:20px 20px 0px 20px" align="left">
                        <div style="font-family:Roboto,Arial,Helvetica;font-size:15px;line-height:22px;color:#4e4e4e">Hello <strong>user</strong> Welcome to ' . (Helpers::settings()->project_name ?? '') . '.Join the best community of Fans. Come play our Fantasy Cricket.<br> To verify your email account please use this OTP <strong>' . $checkdata1->code . '</strong>
                        </div>
                        </td>
                    </tr>';
                $msg = Helpers::mailbody1($content);
                $datamessage['email'] =  $checkdata1->email;
                $datamessage['subject'] = $emailsubject;
                $datamessage['content'] = $msg;
                // Helpers::mailsentFormat($checkdata1->$email, $emailsubject, $msg);
                $json['success'] = true;
                $json['message'] = 'OTP Send';
                return response()->json($json);
                die;
            } else {
                $json['success'] = false;
                $json['message'] = 'Invalid id provide';
                return response()->json($json);
                die;
            }
        } else {
            $json['success'] = false;
            $json['message'] = 'Unauthorized Request';
            return response()->json(array($json));
            die;
        }
        // }
    }

    public function getmainbanner()
    {
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $json = array();
        $findsidebanner = DB::table('sidebanner')->get();
        if (!empty($findsidebanner)) {
            $i = 0;
            foreach ($findsidebanner as $value) {
                $json[$i]['image'] = $geturl . 'public/' . $value->image;
                $json[$i]['type'] = $value->type;
                $json[$i]['url'] = ( !empty($value->url) ) ? $value->url : '';
                $i++;
            }
            return response()->json($json);
            die;
        }
    }
  
    public function category()
    {
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $json = array();
        $findcategory = DB::table('category')->get();
       //dd($findcategory);
        if (!empty($findcategory)) {
            $i = 0;
            foreach ($findcategory as $value) {
                $json[$i]['image'] = $geturl . 'public/' . $value->image;
                $json[$i]['category_id'] = $value->id;
                $json[$i]['status'] = $value->status;
                $json[$i]['category_name'] = $value->category_name;
               // $json[$i]['url'] = ( !empty($value->url) ) ? $value->url : '';
                $i++;
            }
            return response()->json($json);
            die;
        }
    }

    public function products()
    {
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $json = array();
        $findproducts = DB::table('products')->get();
       //dd($findcategory);
        if (!empty($findproducts)) {
            $i = 0;
            foreach ($findproducts as $value) {
                $json[$i]['product_images'] = $geturl . 'public/' . $value->product_images;
                $json[$i]['title'] = $value->title;
                $json[$i]['subtitle'] = $value->subtitle;
                $json[$i]['purchase_price'] = $value->purchase_price;
                $json[$i]['sale_price'] = $value->sale_price;
                $json[$i]['quantity'] = $value->quantity;
                $json[$i]['description'] = $value->description;
               // $json[$i]['url'] = ( !empty($value->url) ) ? $value->url : '';
                $i++;
            }
            return response()->json($json);
            die;
        }
    }
    
    public function subcategory()
    {
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $json = array();
        $findsubcategory = DB::table('subcategory')->get();
       //dd($findcategory);
        if (!empty($findsubcategory)) {
            $i = 0;
            foreach ($findsubcategory as $value) {
                $json[$i]['image'] = $geturl . 'public/' . $value->image;
                $json[$i]['status'] = $value->status;
                $json[$i]['category_id'] = $value->category_id;
                $json[$i]['sub_category_id'] = $value->id;
                $json[$i]['subcategory_name'] = $value->subcategory_name;
               // $json[$i]['url'] = ( !empty($value->url) ) ? $value->url : '';
                $i++;
            }
            return response()->json($json);
            die;
        }
    }

      
    public function searchproduct(Request $request)
    {
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $user = Helpers::isAuthorize($request);
       // $user_id =  $user->id;
        $getusername = $request->get('title');
        $json = array();
        if(!empty($getusername)){
            $getdata = DB::table('products')->where('title','LIKE','%'.$getusername.'%')->get();
            if(!empty($getdata)){
               $i=0;
                foreach($getdata as $getdatas){
                    $json[$i]['product_id'] = $getdatas->product_id;
                    $json[$i]['product_images'] = $geturl . 'public/' . $getdatas->product_images;
                    $json[$i]['title'] = $getdatas->title;
                    $json[$i]['subtitle'] = $getdatas->subtitle;
                    $json[$i]['purchase_price'] = $getdatas->purchase_price;
                    $json[$i]['sale_price'] = $getdatas->sale_price;
                    $json[$i]['discount'] = $getdatas->discount;
                  //  $json[$i]['dob'] = $getdatas->dob;
                    $i++;
                } 
                return response()->json($json);
            }
        }else{
            $json['success'] = false;
            $json['message'] = 'Enter Required Field!';
            return response()->json($json);
        }
    }
   
    public function singleproduct(Request $Request)
    {
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $user = Helpers::isAuthorize($Request);
        $getusername = $Request->get('id');
        $json = array();
        if(!empty($getusername)){
            $getdata = DB::table('products')->where('product_id','LIKE','%'.$getusername.'%')->get();
            if(!empty($getdata)){
                $i=0;
                foreach($getdata as $getdatas){
                    $json[$i]['product_id'] = $getdatas->product_id;
                    $json[$i]['product_images'] = $geturl . 'public/' . $getdatas->product_images;
                    $json[$i]['title'] = $getdatas->title;
                    $json[$i]['subtitle'] = $getdatas->subtitle;
                    $json[$i]['purchase_price'] = $getdatas->purchase_price;
                    $json[$i]['sale_price'] = $getdatas->sale_price;
                    $json[$i]['discount'] = $getdatas->discount;
                  //  $json[$i]['dob'] = $getdatas->dob;
                    $i++;
                    return response()->json($json);
                }
            }else{
                $json['success'] = false;
                $json['message'] = 'Enter Required Field!';
                return response()->json($json);
            }
                }
    }

      
   public function categoryproduct(Request $Request)
   {
    Helpers::setHeader(200);
    Helpers::timezone();
    $geturl = Helpers::geturl();
    $user = Helpers::isAuthorize($Request);
    $getusername = $Request->get('category_id');
    $json = array();
    if(!empty($getusername)){
        $getdata = DB::table('products')->where('category',$getusername)->get();
       // dd($getdata);
        if(!empty($getdata)){
            $i=0;
            foreach($getdata as $getdatas){
                $json[$i]['product_id'] = $getdatas->product_id;
                $json[$i]['product_images'] = $geturl . 'public/' . $getdatas->product_images;
                $json[$i]['title'] = $getdatas->title;
                $json[$i]['subtitle'] = $getdatas->subtitle;
                $json[$i]['purchase_price'] = $getdatas->purchase_price;
                $json[$i]['sale_price'] = $getdatas->sale_price;
                $json[$i]['discount'] = $getdatas->discount;
                $i++;
              
            }
            return response()->json($json);
        }else{
            $json['success'] = false;
            $json['message'] = 'Enter Required Field!';
            return response()->json($json);
        }
            }
   }

    public function subcategoryproduct(Request $Request)
    {
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $user = Helpers::isAuthorize($Request);
        $getusername = [$Request->get('category_id'),$Request->get('subcategory_id')];
        $json = array();
        if(!empty($getusername)){
            $getdata = DB::table('products')->where('category',$getusername[0])
            ->where('sub_category',$getusername[1])->get();
        // dd($getdata);
            if(!empty($getdata)){
                $i=0;
                foreach($getdata as $getdatas){
                    $json[$i]['product_id'] = $getdatas->product_id;
                    $json[$i]['product_images'] = $geturl . 'public/' . $getdatas->product_images;
                    $json[$i]['title'] = $getdatas->title;
                    $json[$i]['subtitle'] = $getdatas->subtitle;
                    $json[$i]['purchase_price'] = $getdatas->purchase_price;
                    $json[$i]['sale_price'] = $getdatas->sale_price;
                    $json[$i]['discount'] = $getdatas->discount;
                    $i++;
                
                }
                return response()->json($json);
            }else{
                $json['success'] = false;
                $json['message'] = 'Enter Required Field!';
                return response()->json($json);
            }
                }
    }

    public function userdetails(Request $Request)
    {
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $user = Helpers::isAuthorize($Request);
        $user_id = $user->id;
        $json = array();
        if(!empty($user_id)){
            $getdata = DB::table('registerusers')->where('id',$user_id)->get();
        // dd($getdata);
            if(!empty($getdata)){
                $i=0;
                foreach($getdata as $getdatas){
                    $json[$i]['id'] = $getdatas->id;
                    $json[$i]['image'] = $geturl . 'public/' . $getdatas->image;
                    $json[$i]['fullname'] = $getdatas->fullname;
                    $json[$i]['email'] = $getdatas->email;
                    $json[$i]['mobile'] = $getdatas->mobile;
                    $json[$i]['address'] = $getdatas->address;
                    $json[$i]['city'] = $getdatas->city;
                    $json[$i]['state'] = $getdatas->state;
                    $json[$i]['dob'] = $getdatas->dob;
                    $json[$i]['gender'] = $getdatas->gender;
                    $i++;
                
                }
                return response()->json($json);
            }else{
                $json['success'] = false;
                $json['message'] = 'Enter Required Field!';
                return response()->json($json);
            }
                }
    }
    
    public function addcart(Request $request){
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $user = Helpers::isAuthorize($request);
        $getproductit = $request->get('product_id');
        $user_id = $user->id;
        // dd($user_id);
      if($getproductit==''){
          return response()->json(array('fgdhjkl'));
      }
       
            $get_product= DB::table('products')->where('product_id',$getproductit)->first();
            // dd($get_product);
            if(!empty($get_product)){
                $product['id'] = 1;
                $product['pid'] = $get_product->product_id;
                $product['title'] = $get_product->title;
                $product['amount'] = $get_product->amount;
                $product['image'] = $get_product->main_image;
                $product['quantity'] = $get_product->quantity;
                $product['p_amt'] = 1 * $get_product->amount;
                $product['prod_qty'] = 1;
                $data['user_id'] = $user_id;   
                // $user_id = $user->id;
                // dd($user_id);
                $check = DB::table('cart')->where('user_id',$user_id)->first();
            //    dd($check);
                if(!empty($check)){
                //    dd('sdfg');
                    $cart_data = json_decode($check->cart_product);
                    $getprodid = strval(array_search($product['pid'],array_column($cart_data,'pid')));
                //    dd($getprodid);
                    if($getprodid!= ""){
                      //  dd('111');
                        
                        // dd('number');
                        $cart_data[$getprodid]->prod_qty = $cart_data[$getprodid]->prod_qty+1;
                        $cart_data[$getprodid]->p_amt = $cart_data[$getprodid]->prod_qty * $cart_data[$getprodid]->amount;
                        $decode_data = json_encode($cart_data);
                        $dataaa=DB::table('cart')->update(['cart_product'=>$decode_data]);
                        return response()->json("update");
                      
                    }else{


                        dd('false boolean');
                        $product['id'] = count($cart_data)+1;
                        array_push($cart_data,$product);
                        $decode_data = json_encode($cart_data);
                        DB::table('cart')->update(['cart_product'=>$decode_data]);
                        
                    }

                   
                }else{
                    $data['cart_product'] = json_encode(array($product));
                    // dd($data);
                    DB::table('cart')->insert($data);
                    return response()->json("insert");
                }
                return response()->json("error");
            }
        // }
        // dd('hgd');
    }



    public function forgotpassword(Request $request)
    {
        try {
            Helpers::setHeader(200);
            if ($request->isMethod('post')) {
                $username = $request->get('username');
              //  dd($username);
                $newmailaddress = Helpers::getnewmail($username);
                $finddetails = DB::table('registerusers')->where(function ($query) use ($username, $newmailaddress) {
                    $query->where('email', '=', $username);
                    $query->orWhere('email', '=', $newmailaddress);
                })->orWhere('mobile', $username)->first();
                $json = array();
                if (!empty($finddetails)) {
                    if ($finddetails->status == 'activated') {
                        // $input['code'] = rand(1000, 9999);
                          $input['code'] = 1234;
                        DB::connection('mysql2')->table('registerusers')->where('id', $finddetails->id)->update($input);
                        if ($finddetails->mobile == $username) {
                            $message = $input['code'] . " is the OTP for your " . (Helpers::settings()->project_name ?? '') . " account. NEVER SHARE YOUR OTP WITH ANYONE. " . (Helpers::settings()->project_name ?? '') . " will never call or message to ask for the OTP.";
                            Helpers::sendTextSmsNew($message, $finddetails->mobile);
                            $json['success'] = true;
                            $json['message'] = 'OTP sent on your mobile number.';
                            return response()->json($json);
                        }
                        if ($username == $finddetails->email || $newmailaddress == $finddetails->email) {
                            /* send mail */
                            $emailsubject = 'Reset Password - ' . Helpers::projectName();
                            $datamessage['email'] = $username;
                            $datamessage['subject'] = $emailsubject;
                            $datamessage['content'] = Helpers::mailbody($input['code']);
                            // Helpers::mailSmtpSend($datamessage);
                            /* end code for send mail */
                            $json['success'] = true;
                            $json['message'] = 'We have sent you an OTP on your registered email address. Please check your email and reset your password.';
                            return response()->json($json);
                        }
                    } else {
                        $json['success'] = false;
                        $json['message'] = 'Sorry you cannot reset your password now. Please contact to administrator.';
                        return response()->json($json);
                    }
                } else {
                    $json['success'] = false;
                    $json['message'] = 'You have entered invalid details to reset your password.';
                    return response()->json($json);
                }
            } else {
                $msgg['success'] = false;
                $msgg['message'] = 'Unauthorized request';
                echo json_encode($msgg);
                die;
            }

        } catch (\Exception $e) { 
            Log::info($e->getMessage());
            return response()->json(array(['success' => false, 'message' => $e->getMessage()])); 
        }
    }


    public function changepassword(Request $request)
    {
        Helpers::setHeader(200);
        Helpers::timezone();
        if ($request->isMethod('post')) {
            $input = $request->all();
         
            /* check authentication*/
            $user = Helpers::isAuthorize($request);
            unset($input['auth_key']);
            $getid = $user->id;
            $newpassword = "";
            $oldpassword = $input['oldpassword'];
            $newpassword = $input['newpassword'];
            $confirmpassword = $input['confirmpassword'];
            if ($newpassword == $confirmpassword) {
                $password = $newpassword;
                $findusers = DB::table('registerusers')->where('id', $getid)->select('id', 'password')->first();
                if (!empty($findusers)) {
                    if (Hash::check($oldpassword, $findusers->password)) {
                        $data['password'] =  Hash::make($password);
                        $data['auth_key'] = md5(Hash::make($password));
                        DB::connection('mysql2')->table('registerusers')->where('id', $findusers->id)->update($data);
                        $json['success'] = true;
                        $json['auth_key'] = $data['auth_key'];
                        $json['message'] = 'Password Changed Successfully';
                        return response()->json(array($json));
                    } else {
                        $json['success'] = false;
                        $json['message'] = 'Old password does not matched to previous password.';
                        return response()->json(array($json));
                    }
                } else {
                    $json['success'] = false;
                    $json['message'] = 'password is not exsited in database.';
                    return response()->json(array($json));
                }
            } else {
                $response['success'] = false;
                $response['message'] = 'Confirm password and new not matched';
                return response()->json(array($response));
            }
        } else {
            $msgg['success'] = false;
            $msgg['message'] = 'Unauthorized request';
            echo json_encode(array($msgg));
            die;
        }
    }
    
    
    
     

}