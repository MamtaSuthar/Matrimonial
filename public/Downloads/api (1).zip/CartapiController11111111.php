<?php

namespace App\Http\Controllers\api;

use DB;
use Session;
use bcrypt;
use Config;
use Redirect;
use App\Helpers\Helpers;
use Hash;
use Mail;
use Cache;
use Crypt;

use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests;
// use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use CfPayout;
use Validator;
use Razorpay\Api\Api;
// use Helpers;
use Log;

class CartapiController extends Controller
{
    public function addcart(Request $request){
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $user = Helpers::isAuthorize($request);
        $getproductit = $request->get('product_id');
        $user_id = $user->id;
        // dd($user_id);
      if($getproductit==''){
          return response()->json(array('fgdhjkl'));
      }
       
            $get_product= DB::table('products')->where('product_id',$getproductit)->first();
            // dd($get_product);
            if(!empty($get_product)){
                $product['id'] = 1;
                $product['pid'] = $get_product->product_id;
                $product['title'] = $get_product->title;
                $product['amount'] = $get_product->amount;
                $product['image'] = $get_product->main_image;
                $product['quantity'] = $get_product->quantity;
                $product['p_amt'] = 1 * $get_product->amount;
                $product['prod_qty'] = 1;
                $data['user_id'] = $user_id;   
                // $user_id = $user->id;
                // dd($user_id);
                $check = DB::table('cart')->where('user_id',$user_id)->first();
            //    dd($check);
                if(!empty($check)){
                //    dd('sdfg');
                    $cart_data = json_decode($check->cart_product);
                   // dd($cart_data);
                    $getprodid = strval(array_search($product['pid'],array_column($cart_data,'pid')));
                //    dd($getprodid);
                    if($getprodid!= ""){
                      //  dd('111');
                        
                        // dd('number');
                        $cart_data[$getprodid]->prod_qty = $cart_data[$getprodid]->prod_qty+1;
                        $cart_data[$getprodid]->p_amt = $cart_data[$getprodid]->prod_qty * $cart_data[$getprodid]->amount;
                        $decode_data = json_encode($cart_data);
                        $dataaa=DB::table('cart')->update(['cart_product'=>$decode_data]);
                        // return response()->json("update");
                        return response()->json(array(['status'=>'success','data'=>"add to cart successfully update"]));
                      
                    }else{


                      // dd('false boolean');
                        $product['id'] = count($cart_data)+1;
                        array_push($cart_data,$product);
                        $decode_data = json_encode($cart_data);
                        DB::table('cart')->update(['cart_product'=>$decode_data]);
                        
                    }

                   
                }else{
                    $data['cart_product'] = json_encode(array($product));
                    // dd($data);
                    DB::table('cart')->insert($data);
                    // return response()->json("insert");
                    return response()->json(array(['status'=>'success','data'=> "add to cart successfully"]));
                }
                // return response()->json("error");
                return response()->json(array(['status'=>'success','data'=>"add to cart successfully" ]));
            }
        // }
        // dd('hgd');
    }


    public function add_item(Request $request){

        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $user = Helpers::isAuthorize($request);  
       $user_id = $user->id;
    //    $key = $request->get('index_id');
       $pid = $request->get('product_id');

        $cartdata = DB::table('cart')->where('user_id',$user_id)->first();
        // dd($cartdata);
        $dump=json_decode($cartdata->cart_product);
        // $collectionA = collect([$dump]);
        $test=array_column($dump,'pid'); 
        $keys = array_search($pid, $test);
        if(!empty($cartdata) && $cartdata->cart_product!=null){
      
            $cartitems = json_decode($cartdata->cart_product);
          //  dd($cartitems);
           
           $itemdata=$cartitems[$keys];
        //    dd($pid,$itemdata)
           // $itemdata = collect($cartitems)->get($keys);
         //  $itemdata = collect($cartitems)->get($key);
          // dd($itemdata);
                $itemdata->prod_qty = $itemdata->prod_qty+1;

                $cartsss = collect($cartitems);
                
              
                 
                $cartsss->each(function ($item, $user_id) {
                    $item->p_amt = $item->amount * $item->prod_qty;
                });
               //  dd($cartsss);
                // dd($data);
                $dddd=[];
                foreach($cartsss as $cartss){
                    $dddd[] = $cartss;
                }
                // $dddd = $cartsss->toArray();
                // dd($dddd);
               // dd(json_encode($dddd));
                DB::table('cart')->where('user_id',$user_id)->update(['cart_product'=>$cartsss->toJson()]);
                $csum = collect($cartitems)->sum('p_amt');
                
                // $data = ['cartitems'=>$cartsss,'cart_Total'=>$csum ,'userid'=> $user_id];
                return response()->json(array(['status'=>'success','data'=>"Add Data successfuly" ]));
        }
    }


    public function remove_item(Request $request){
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $user = Helpers::isAuthorize($request); 
        $user_id = $user->id;
        $pid = $request->get('product_id');
        $cartdata = DB::table('cart')->where('user_id',$user_id)->first();
    //   dd($cartdata);
        $dump=json_decode($cartdata->cart_product);
        // $collectionA = collect([$dump]);
        $test=array_column($dump,'pid'); 
        $keys = array_search($pid, $test);
        // dd($keys);
        if(!empty($cartdata) && $cartdata->cart_product!=null){
    
            $cartitems = json_decode($cartdata->cart_product);
        
            $itemdata=$cartitems[$keys];
           // dd($itemdata);
            if($itemdata->prod_qty != 1){
                    $itemdata->prod_qty = $itemdata->prod_qty-1;
                    $cartsss = collect($cartitems);
                    $cartsss->each(function ($item, $keys){
                        $item->p_amt = $item->amount * $item->prod_qty;
                    });
                //    $dddd = $cartsss->toArray();
                    // dd($cartsss->toArray());
                    DB::table('cart')->where('user_id',$user_id)->update(['cart_product'=>$cartsss->toJson()]);
                    $csum = collect($cartitems)->sum('p_amt');
                    // $dd = view('frontend.renders.cartItems');
                    // $view = $dd->render();
                    // dd('jhgfd');
                    // $data = ['cartitems'=>$cartsss,'cart_Total'=>$csum ,'userid'=> $user_id];
                    return response()->json(array(['status'=>'success','data'=>"remove " ]));
            }else{
                return response()->json(array(['status'=>'error','message'=>'quantity cannot be less than 1']));
            }
            }
        




    }



    public function view_cart(Request $request){
        Helpers::setHeader(200);
        Helpers::timezone();
        $geturl = Helpers::geturl();
        $user = Helpers::isAuthorize($request);
        $uid = $user->id;
        // $pid = $request->get('id');
       // dd($uid);
        
        // $uid = $_GET['cart_id'];
        //  dd($uid);
        $catg = DB::table('category')->get();
        $cartitem = DB::table('cart')->where('user_id',$uid)->first();
              $cartproduct=json_decode($cartitem->cart_product);

        // $coupon_code = DB::table('orders')->select('coupon_code')->where('user_id',$uid)->get();
        // $getproduct = DB::table('products')->get();
       
        $cart_prod="";
        $csum=0;
        if(!empty($cartitem)){
            $cart_prod = json_decode($cartitem->cart_product);   
            $csum=collect($cart_prod)->sum('p_amt');
        }   
        $json['success'] = true;
        $json['message'] = 'view_cart';
        $json['Total'] =$csum;
        $json['data'] =$cartproduct;
  
        return response()->json(array($json,));
        

       
    }


    public function getversion()
    {
     
        $version = DB::table('androidversion')->select('version','updation_points','ios')->first();
        if (!empty($version)) {
            $msgg['status'] = $version->version;
            $msgg['ios'] = $version->ios;
            $msgg['point'] = $version->updation_points;
            $msgg['success'] = true;
            echo json_encode(array($msgg));
            die;
        } else {
            $msgg['success'] = false;
            echo json_encode(array($msgg));
            die;
        }
        echo json_encode($msgg);
        die;
    }




}



