<?php
namespace App\Http\Controllers\api;

use DB;
use Session;
use bcrypt;
use Config;
use Redirect;
use App\Helpers\Helpers;
use Hash;
use Mail;
use Cache;
use Crypt;

use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests;
// use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use CfPayout;
use Dotenv\Result\Success;
use Validator;
use Razorpay\Api\Api;
// use Helpers;
use Log;

use function PHPSTORM_META\type;

class CartapiController extends Controller
{

  public function addcart(Request $request){
    Helpers::setHeader(200);
    Helpers::timezone();
    $geturl = Helpers::geturl();
    $user = Helpers::isAuthorize($request);
    $getproductit = $request->get('product_id');
    $status = $request->get('status');
    $pqty = $request->get('pqty');
    $user_id = $user->id;
    if($getproductit==''){
      return response()->json(array('No such product found'));
    }

    $get_product= DB::table('products')->where('product_id',$getproductit)->first();
    
    if(!empty($get_product)){
        $product['id'] = 1;
        $product['pid'] = $get_product->product_id;
        $product['title'] = $get_product->title;
        $product['amount'] = $get_product->purchase_price;
        $product['saleamount'] = $get_product->sale_price;
        $product['image'] = $get_product->main_image;
        $product['quantity'] = $get_product->quantity;
        
        // $product['p_amt'] = 1 * $get_product->purchase_price;
        $product['description']= $get_product->description;
        $product['prod_qty'] = (!empty($pqty))?$pqty:1;
        if($status=="buynow"){
          $product['prod_qty'] = $pqty;
          $product['p_amt'] = $get_product->purchase_price*$pqty;
        }else{
          $product['prod_qty'] = 1;
          $product['p_amt'] = 1 * $get_product->purchase_price;
        }
        // $product['prod_qty'] = 1;
        $data['user_id'] = $user_id;  

        $check = DB::table('cart')->where('user_id',$user_id)->first();
        if(!empty($check)){
          if($status=="buynow"){                
            $data['buy_porduct'] = json_encode(array($product));        
            DB::table('cart')->where('user_id',$user_id)->update($data);
            return response()->json(array(['status'=>true,'msg'=> "Buy to cart successfully"]));
          }else{
              $cart_data = json_decode($check->cart_product);
              if(empty($cart_data)){
                
                $data['cart_product'] = json_encode(array($product));        
                DB::table('cart')->where('user_id',$user_id)->update($data);
              }else{
                    $getprodid = strval(array_search($product['pid'],array_column($cart_data,'pid')));
                    if($getprodid!= ""){

                        $cart_data[$getprodid]->prod_qty = $cart_data[$getprodid]->prod_qty+1;
                        $cart_data[$getprodid]->p_amt = $cart_data[$getprodid]->prod_qty * $cart_data[$getprodid]->amount;
                        $decode_data = json_encode($cart_data);
              
                        $dataaa=DB::table('cart')->where('user_id',$user_id)->update(['cart_product'=>$decode_data]);
                        // return response()->json("update");
                        return response()->json(array(['status'=>true,'msg'=>"add to cart successfully update"]));
                      
                    }else{
                        $product['id'] = count($cart_data)+1;
                        array_push($cart_data,$product);
                        $decode_data = json_encode($cart_data);
                        DB::table('cart')->where('user_id',$user_id)->update(['cart_product'=>$decode_data]);                     
                    }
              }
            }
          
        }else{
          
          if($status=="buynow"){
              $data['buy_porduct'] = json_encode(array($product));        
              $data['cart_product'] = json_encode(array());        
              DB::table('cart')->where('user_id',$user_id)->insert($data);
              return response()->json(array(['status'=>true,'msg'=> "Buy to cart successfully"]));
          }else{
              $data['cart_product'] = json_encode(array($product));        
              $data['buy_porduct'] = json_encode(array());        
              DB::table('cart')->where('user_id',$user_id)->insert($data);
              return response()->json(array(['status'=>true,'msg'=> "add to cart successfully"]));
          }
          
        }                
        return response()->json(array(['status'=>true,'msg'=>"add to cart successfully" ]));
    }else{
      return response()->json(array(['status'=>false,'msg'=>"No such product id found" ]));
    }
  }


}



