<?php
$keyId = 'rzp_test_OlFrctTFDAFnKO';
$keySecret = 'QNuv3PGL6MuWl2XsbHjTdtjT';
// $keyId = 'rzp_live_H1yzsrPv3N8T5e';
// $keySecret = 'LroOxClmj84kouR3GdJyCma4';
$displayCurrency = 'INR';
error_reporting(E_ALL);
ini_set('display_errors', 1);
