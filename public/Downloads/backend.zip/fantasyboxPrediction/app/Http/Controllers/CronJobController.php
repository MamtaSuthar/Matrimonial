<?php
namespace App\Http\Controllers;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use DB;
use Illuminate\Http\Request;
use PHPExcel_IOFactory;

class CronJobController extends Controller
{

    public function dailyreport(Request $request)
    {
        $date = date('Y-m-d');
        $pdate = date('Y-m-d', strtotime(date('Y-m-d') . '-2 day'));

        $data = DB::table('listmatches')->where('final_status', 'winnerdeclared')->where('fantasy_type', 'cricket')->whereDate('start_date', '>=', $pdate)->groupBy(DB::raw('DATE(start_date)'))->get(['start_date']);

        $dates = [];
        if (!empty($data->toArray())) {
            foreach ($data as $d) {

                $day = DB::table('listmatches')->join('profitloss', 'profitloss.matchkey', 'listmatches.matchkey')->where('listmatches.final_status', 'winnerdeclared')->where('listmatches.fantasy_type', 'cricket')->where('listmatches.start_date', 'LIKE', '%' . date('Y-m-d', strtotime($d->start_date)) . '%')->get(['listmatches.start_date', 'listmatches.final_status', 'listmatches.matchkey', 'profitloss.profit_or_loss', 'profitloss.amount_profit_or_loss']);
                if (!empty($day->toArray())) {
                    dump(date('Y-m-d', strtotime($d->start_date)));
                    $rem_amount = 0;
                    $profit = 0;
                    $loss = 0;
                    foreach ($day as $val) {
                        if ($val->profit_or_loss == 'Loss') {
                            $loss += $val->amount_profit_or_loss;
                        }
                        if ($val->profit_or_loss == 'Profit') {
                            $profit += $val->amount_profit_or_loss;
                        }

                    }
                    $received = DB::table('paymentprocess')->where('status', 'success')->where('created_at', 'LIKE', '%' . date('Y-m-d', strtotime($d->start_date)) . '%')->sum('amount');
                    $withdraw = DB::table('withdraw')->where('status', 1)->where('approved_date', 'LIKE', '%' . date('Y-m-d', strtotime($d->start_date)) . '%')->sum('amount');
                    $cashfreeR = ($received * 2) / 100;
                    $cashfreeW = ($withdraw * 2) / 100;
                    $rem_amount = $profit - $loss - $cashfreeR - $cashfreeW;
                    $info['report_date'] = date('Y-m-d', strtotime($d->start_date));
                    $info['net_amount'] = number_format($rem_amount, 2, ".", "");
                    $info['total_received'] = number_format($received, 2, ".", "");
                    $info['total_withdraw'] = number_format($withdraw, 2, ".", "");
                    $info['cashfreeRper'] = number_format($cashfreeR, 2, ".", "");
                    $info['cashfreeWper'] = number_format($cashfreeW, 2, ".", "");
                    $info['profit'] = number_format($profit, 2, ".", "");
                    $info['loss'] = number_format($loss, 2, ".", "");
                    $daily_data = DB::table('daily_report')->where('report_date', 'LIKE', '%' . date('Y-m-d', strtotime($d->start_date)) . '%')->first();

                    if (!empty($daily_data)) {
                        $up = DB::connection('mysql2')->table('daily_report')->where('id', $daily_data->id)->update($info);

                    } else {
                        DB::connection('mysql2')->table('daily_report')->insert($info);
                    }

                }

            }
        }
    }

    public function uploadExcelll(Request $request)
    {
        if ($request->isMethod('post')) {
            $input = $request->all();
            require_once './PHPExcel/PHPExcel/IOFactory.php';
            if (isset($_FILES["excel_file"]["name"])) {
                $path = $_FILES["excel_file"]["tmp_name"];
                $object = PHPExcel_IOFactory::load($path);
                foreach ($object->getWorksheetIterator() as $worksheet) {
                    $highestRow = $worksheet->getHighestRow();
                    $highestColumn = $worksheet->getHighestColumn();
                    $starti = 1;
                    $counti = 1;
                    for ($row = 2; $row <= $highestRow; $row++) {
                        $data['transferid'] = $worksheet->getCellByColumnAndRow(1, $row)->getValue();
                        $data['amount'] = $worksheet->getCellByColumnAndRow(2, $row)->getValue();
                        $data['status'] = $worksheet->getCellByColumnAndRow(3, $row)->getValue();
                        $data['beneficiary'] = $worksheet->getCellByColumnAndRow(5, $row)->getValue();
                        $data['referenceid'] = $worksheet->getCellByColumnAndRow(9, $row)->getValue();
                        $data['date'] = $worksheet->getCellByColumnAndRow(0, $row)->getValue();

                        DB::connection('mysql2')->table('check_withdraw')->insert($data);
                    }

                }
            }
        }
    }

    public function youtubernotification()
    {
        $wonyoutubers = DB::table('youtuber_bonus')->where('status', 0)->get();
        foreach ($wonyoutubers as $value) {
            $notification['userid'] = $value->userid;
            $notification['seen'] = 0;
            $titleget = "Youtuber Profit";
            $msg = $notification['title'] = 'You have received Rs. ' . number_format($value->amount, 2, '.', '') . ' as profit from your referred users';
            Helpers::sendnotification($titleget, $msg, '', $value->userid);

            $data = array();
            $data['status'] = 1;
            DB::connection('mysql2')->table('youtuber_bonus')->where('id', $value->id)->update($data);
        }
    }
    // public function changeprice($challengeid)
    // {
		//     $findchallenge = DB::table('matchchallenges')->where('id', $challengeid)->where('pricecard_type', 'Percentage')->where('price_status', 0)->first();
		//     if (!empty($findchallenge)) {
		//         $bonus_used = DB::table('leaugestransactions')->where('challengeid', $challengeid)->sum('bonus');
		//         $contest_winners = DB::table('matchpricecards')->where('challenge_id', $challengeid)->sum('winners');
		//         $pricecards = DB::table('matchpricecards')->where('challenge_id', $challengeid)->get();
		//         if (!empty($pricecards->toArray()) && $findchallenge->joinedusers > 0) {
		//             $maxusers = $findchallenge->maximum_user;
		//             dump('maxusers------' . $maxusers);
		//             $joined = $findchallenge->joinedusers;
		//             dump('joined------' . $joined);
		//             $win_amt = $findchallenge->win_amount;
		//             dump('win_amt------' . $win_amt);
		//             $entryfee = $findchallenge->entryfee;
		//             dump('entryfee------' . $entryfee);
		//             $amount_before_live = $entryfee * $maxusers;
		//             dump('amount_before_live------' . $amount_before_live);
		//             $distribution_percentage = number_format(($win_amt / $amount_before_live) * 100, 2, '.', '');
		//             dump('distribution_percentage------' . $distribution_percentage);
		//             $received_amt = $entryfee * $joined;
		//             dump('received_amt------' . $received_amt);
		//             dump('bonus used by users--------' . $bonus_used);
		//             $received_amt = $received_amt - $bonus_used;
		//             dump('received amount after bonus deduction ---------' . $received_amt);
		//             $new_win_amt = number_format((($received_amt * $distribution_percentage) / 100), 2, '.', '');
		//             dump('new_win_amt------' . $new_win_amt);
		//             if ($joined > $contest_winners) {
		//                 $newwinners = $contest_winners;
		//             } else {
		//                 $newwinners = round(($joined * 40) / 100);
		//             }

		//             dump('newwinners------' . $newwinners);
		//             $distributed_amt = 0;
		//             $distributed = [];
		//             $ranked = $pricecards->pluck('price_percent', 'max_position');
		//             $ranked_new = $ranked->toArray();
		//             dump($ranked->toArray());
		//             $ranks = array_keys($ranked->toArray());
		//             $x = $newwinners;
		//             // dd($x);
		//             $z = array_reduce($ranks, function ($max, $number) use ($x) {
		//                 dump('max----' . $number);
		//                 // Ignore if greater
		//                 if ($number >= $x) {
		//                     return $max;
		//                 }

		//                 // First one less than x
		//                 if ($max === null) {
		//                     return $number;
		//                 }

		//                 // Replace if greater
		//                 return $max < $number ? $number : $max;

		//             }, null);
		//             // dump('z');dump($z);
		//             // dd($ranks);
		//             $key_index = $ranked_new[$ranks[array_search($z, $ranks) + 1]];
		//             $key = array_search($key_index, $ranked_new);

		//             $data = array_filter($ranked_new, function ($v) use ($key) {return $v <= $key;}, ARRAY_FILTER_USE_KEY);
		//             dump($data);
		//             $i = 0;
		//             $rem_amount = 0;
		//             $winn = [];
		//             $ids = '';
		//             foreach ($pricecards as $key => $value) {
		//                 if ($i < count($data)) {
		//                     $amts = ($new_win_amt * $value->price_percent) / 100;
		//                     $amts_total = 0;
		//                     dump($i);
		//                     // dd($value->max_position.'--------'.$newwinners);

		//                     if ($value->max_position <= $newwinners) {
		//                         $amts_total = $amts * $value->winners;
		//                         $ids = ($ids != '') ? $ids . ',' . $value->id : $value->id;
		//                         $winn[$i]['id'] = $value->id;
		//                         $winn[$i]['min_position'] = $value->min_position;
		//                         $winn[$i]['max_position'] = $value->max_position;
		//                         $winn[$i]['winners'] = $value->winners;
		//                         $winn[$i]['amount_per'] = number_format($amts, 2, '.', '');
		//                         $winn[$i]['total'] = $amts_total;
		//                     } else {
		//                         $winr = $newwinners - ((isset($pricecards[$i - 1])) ? $pricecards[$i - 1]->max_position : $pricecards[$i]->max_position);
		//                         $ids = ($ids != '') ? $ids . ',' . $value->id : $value->id;
		//                         $winn[$i]['id'] = $value->id;
		//                         $winn[$i]['min_position'] = $value->min_position;
		//                         $winn[$i]['max_position'] = $value->max_position;
		//                         $winn[$i]['winners'] = $winr;
		//                         $winn[$i]['amount_per'] = number_format($amts, 2, '.', '');
		//                         $winn[$i]['total'] = $amts * $winr;
		//                         $amts_total = $amts * $winr;
		//                     }
		//                     $distributed[] = $amts_total;
		//                 } else {

		//                     break;
		//                 }
		//                 $i++;
		//             }
		//             $rem_amount = $new_win_amt - array_sum($distributed);
		//             dump('Distributed amount-----------------' . array_sum($distributed));
		//             dump('Remaining------------------' . $rem_amount);
		//             dump($winn);
		//             $single_person_amt = number_format(($rem_amount / $newwinners), 2, '.', '');
		//             dump('Profit to every winner-------------------' . $single_person_amt);
		//             $total_win = 0;
		//             $d = array_map(function ($v) use ($single_person_amt, $new_win_amt, $total_win) {
		//                 // $amt_per = ($v['winners'])?
		//                 // $v['amount_per'] = number_format(floor($v['amount_per']) + $single_person_amt,2,'.','');
		//                 $v['amount_per'] = number_format($v['amount_per'] + $single_person_amt, 2, '.', '');
		//                 $v['total'] = number_format($v['amount_per'] * $v['winners'], 2, '.', '');
		//                 $total_win += $v['total'];
		//                 $v['new_percentage'] = number_format(($v['amount_per'] / $new_win_amt) * 100, 2, '.', '');
		//                 return $v;
		//             }, $winn);
		//             dump($d);
		//             // dd($total_win);
		//             foreach ($d as $k => $val) {
		//                 if ($val['max_position'] < $newwinners) {
		//                     DB::table('matchpricecards')->where('id', $val['id'])->update(['total' => $val['total'], 'price_percent' => $val['new_percentage']]);
		//                 } else {
		//                     $w = $newwinners - $val['min_position'];
		//                     DB::table('matchpricecards')->where('id', $val['id'])->update(['total' => $val['total'], 'price_percent' => $val['new_percentage'], 'max_position' => $newwinners, 'winners' => $w]);
		//                 }

		//             }
		//             $ids = explode(',', $ids);
		//             $wins = array_sum(array_column($d, 'total'));
		//             // dump($wins);
		//             DB::table('matchpricecards')->where('challenge_id', $challengeid)->whereNotIn('id', $ids)->delete();
		//             DB::table('matchchallenges')->where('id', $challengeid)->update(['win_amount' => $wins, 'price_status' => 1]);
		//             // echo '<pre>';print_r($d);

		//         }
		//     }
    // }
	public function changeprice($challengeid)
    {
        date_default_timezone_set('Asia/Kolkata');
        // $findchallenge = DB::table('matchchallenges')->where('id',$challengeid)->where('price_status',0)->first();
        $findchallenge = DB::table('matchchallenges')->where('id', $challengeid)->where('entryfee', '!=', 0)->where('pricecard_type', 'Percentage')->where('price_status', 0)->first();
        //   dump($findchallenge);
        if (!empty($findchallenge)) {
            // \Log::info('contest Compression for Contest id------' . $findchallenge->id);
            // LOG::info(date('Y-m-d H:i:s'));
            $bonus_used = DB::table('leaugestransactions')->where('challengeid', $challengeid)->sum('bonus');
            $contest_winners = DB::table('matchpricecards')->where('challenge_id', $challengeid)->sum('winners');
            $pricecards = DB::table('matchpricecards')->where('challenge_id', $challengeid)->get();
            // dump(!empty($pricecards->toArray()) && $findchallenge->joinedusers>0);
            if (!empty($pricecards->toArray()) && $findchallenge->joinedusers > 0) {
                $maxusers = $findchallenge->maximum_user;
                dump('maxusers------' . $maxusers);
                $joined = $findchallenge->joinedusers;
                dump('joined------' . $joined);
                $win_amt = $findchallenge->win_amount;
                dump('win_amt------' . $win_amt);
                $entryfee = $findchallenge->entryfee;
                dump('entryfee------' . $entryfee);
                $amount_before_live = $entryfee * $maxusers;
                dump('amount_before_live------' . $amount_before_live);
                $distribution_percentage = number_format(($win_amt / $amount_before_live) * 100, 2, '.', '');
                dump('distribution_percentage------' . $distribution_percentage);
                $received_amt = $entryfee * $joined;
                dump('received_amt------' . $received_amt);
                dump('bonus used by users--------' . $bonus_used);
                $received_amt = $received_amt - $bonus_used;
                dump('received amount after bonus deduction ---------' . $received_amt);
                // if contest is full then contest winning amount will not compress
                if ($maxusers == $joined) {
                    $new_win_amt = $win_amt;
                } else {
                    $new_win_amt = number_format(floor((($received_amt * $distribution_percentage) / 100)), 2, '.', '');
                }
                // $new_win_amt = number_format((($received_amt*$distribution_percentage)/100),2,'.','');
                dump('new_win_amt------' . $new_win_amt);
				// dump($new_win_amt>0);die;
				if($new_win_amt>0){
					if ($joined > $contest_winners) {
						$newwinners = $contest_winners;
					} else {
						if ($joined == 1) {
							$newwinners = 1;
							$new_win_amt = $entryfee;
						} else {
							$newwinners = round(($joined * 40) / 100);
							if ($newwinners > 0 && $newwinners < 1) {
								$newwinners = 1;
							}
						}
					}

					dump('newwinners------' . $newwinners);
					$distributed_amt = 0;
					$distributed = [];
					$ranked = $pricecards->pluck('price_percent', 'max_position');
					$ranked_new = $ranked->toArray();
					dump($ranked->toArray());
					$ranks = array_keys($ranked->toArray());
					$x = $newwinners;
					// dd($x);
					$z = array_reduce($ranks, function ($max, $number) use ($x) {
						dump('max----' . $number);
						// Ignore if greater
						if ($number >= $x) {
							return $max;
						}

						// First one less than x
						if ($max === null) {
							return $number;
						}

						// Replace if greater
						return $max < $number ? $number : $max;

					}, null);
					// dump('z');dump($z);
					// dd($ranks);
					// $key_index = $ranked_new[$ranks[array_search($z, $ranks)+1]];
					// $key_index = (isset($ranks[array_search($z, $ranks)+1]))?$ranked_new[$ranks[array_search($z, $ranks)+1]]:$ranked_new[$ranks[array_search($z, $ranks)]];
					if (empty($z)) {
						$key_index = (isset($ranks[array_search($z, $ranks) + 0])) ? $ranked_new[$ranks[array_search($z, $ranks) + 0]] : $ranked_new[$ranks[array_search($z, $ranks)]];
						// dump('Ranked New --------'.isset($ranks[array_search($z, $ranks)]));
					} else {
						$key_index = (isset($ranks[array_search($z, $ranks) + 1])) ? $ranked_new[$ranks[array_search($z, $ranks) + 1]] : $ranked_new[$ranks[array_search($z, $ranks)]];
					}
					$key = array_search($key_index, $ranked_new);

					$data = array_filter($ranked_new, function ($v) use ($key) {return $v <= $key;}, ARRAY_FILTER_USE_KEY);
					dump($data);
					$i = 0;
					$rem_amount = 0;
					$winn = [];
					$ids = '';
					foreach ($pricecards as $key => $value) {
						if ($i < count($data)) {
							$amts = ($new_win_amt * $value->price_percent) / 100;
							$amts_total = 0;
							dump('fdgffghjhgjhg----------' . $i);
							// dd($value->max_position.'--------'.$newwinners);

							if ($value->max_position <= $newwinners) {
								$amts_total = $amts * $value->winners;
								$ids = ($ids != '') ? $ids . ',' . $value->id : $value->id;
								$winn[$i]['id'] = $value->id;
								$winn[$i]['min_position'] = $value->min_position;
								$winn[$i]['max_position'] = $value->max_position;
								$winn[$i]['winners'] = $value->winners;
								$winn[$i]['amount_per'] = number_format($amts, 2, '.', '');
								$winn[$i]['total'] = $amts_total;
							} else {

								$winuserforwinnnn = ((isset($pricecards[$i - 1])) ? $pricecards[$i - 1]->max_position : $pricecards[$i]->max_position);
								$winr = ($newwinners > $winuserforwinnnn) ? $newwinners - $winuserforwinnnn : $newwinners;
								// $ids = ($ids!='')?$ids.','.$value->id:$value->id;
								// $winn[$i]['id'] = $value->id;
								// $winn[$i]['min_position'] = $value->min_position;
								// $winn[$i]['max_position'] = $value->max_position;
								// $winn[$i]['winners'] = $winr;
								// $winn[$i]['amount_per'] = number_format($amts,2,'.','');
								// $winn[$i]['total'] = $amts*$winr;
								// $amts_total = $amts*$winr;
								if ($winr > 0) {
									$ids = ($ids != '') ? $ids . ',' . $value->id : $value->id;
									$winn[$i]['id'] = $value->id;
									$winn[$i]['min_position'] = $value->min_position;
									$winn[$i]['max_position'] = $value->max_position;
									$winn[$i]['winners'] = $winr;
									$winn[$i]['amount_per'] = number_format($amts, 2, '.', ''); // amount per user
									$winn[$i]['total'] = $amts * $winr;
									$amts_total = $amts * $winr;
								}
							}
							$distributed[] = $amts_total;
						} else {

							break;
						}
						$i++;
					}
					$rem_amount = $new_win_amt - array_sum($distributed);
					dump('Distributed amount-----------------' . array_sum($distributed));
					dump('Remaining------------------' . $rem_amount);
					dump($winn);
					$single_person_amt = number_format(($rem_amount / $newwinners), 2, '.', '');
					dump('Profit to every winner-------------------' . $single_person_amt);
					$total_win = 0;
					$d = array_map(function ($v) use ($single_person_amt, $new_win_amt, $total_win) {
						// $amt_per = ($v['winners'])?
						// $v['amount_per'] = number_format(floor($v['amount_per']) + $single_person_amt,2,'.','');
						$v['amount_per'] = number_format($v['amount_per'] + $single_person_amt, 2, '.', '');
						$v['total'] = number_format($v['amount_per'] * $v['winners'], 2, '.', '');
						$total_win += $v['total'];
						$v['new_percentage'] = number_format(($v['amount_per'] / $new_win_amt) * 100, 2, '.', '');
						return $v;
					}, $winn);
					dump($d);
					// dd($total_win);
					foreach ($d as $k => $val) {
						if ($val['max_position'] < $newwinners) {
							DB::table('matchpricecards')->where('id', $val['id'])->update(['total' => $val['total'], 'price_percent' => $val['new_percentage']]);
						} else {
							$w = $newwinners - $val['min_position'];
							if ($joined == 1) {
								DB::table('matchpricecards')->where('id', $val['id'])->update(['total' => $new_win_amt, 'price_percent' => 100, 'max_position' => $newwinners, 'winners' => $w]);
								break;
							} else {
								DB::table('matchpricecards')->where('id', $val['id'])->update(['total' => $val['total'], 'price_percent' => $val['new_percentage'], 'max_position' => $newwinners, 'winners' => $w]);
							}
							//         DB::table('matchpricecards')->where('id',$val['id'])->update(['total'=>$val['total'],'price_percent'=>$val['new_percentage'],'max_position'=>$newwinners,'winners'=>$w]);
						}

					}
					$ids = explode(',', $ids);
					$wins = array_sum(array_column($d, 'total'));
					dump('new winning_amount           ' . $wins);
					DB::table('matchpricecards')->where('challenge_id', $challengeid)->whereNotIn('id', $ids)->delete();
					DB::table('matchchallenges')->where('id', $challengeid)->update(['win_amount' => $wins, 'price_status' => 1]);
					// echo '<pre>';print_r($d);

				}
                
            }
        }
    }
    public function getallmatchestocompress(Request $request)
    {
        $list = DB::table('listmatches')->where('launch_status', 'launched')->whereIn('status', ['started','completed'])->whereIn('final_status',['pending','IsReviewed'])->get();
        if (!empty($list->toArray())) {
            foreach ($list as $key => $value) {

                $challenges = DB::table('matchchallenges')
                    ->join('matchpricecards', 'matchpricecards.challenge_id', 'matchchallenges.id')
                    ->where('matchchallenges.matchkey', $value->matchkey)
                    ->where('matchchallenges.pricecard_type', 'Percentage')
                    ->where('matchchallenges.joinedusers', '>', 1)
                    ->where('matchchallenges.price_status', 0)
                    ->select('matchchallenges.id', DB::raw('COUNT(matchpricecards.challenge_id) as totalpricecards'))
                    ->groupBy('matchchallenges.id')
                    ->having('totalpricecards', '>', 0)
                    ->get();
				// dump($challenges->toArray());continue;
                if (!empty($challenges->toArray())) {
                    foreach ($challenges as $k => $val) {
						// dump($val);
                        $this->changeprice($val->id);
						// echo $val->id.',';
                    }
                }
                // dump($challenges->toArray());
            }
        }
        // dd($list);
    }
    // public function updatePlayersCount()
    // {
    //     date_default_timezone_set('Asia/Kolkata');
    //     $findmatchexist =DB::connection('mysql2')->table('listmatches')->where('fantasy_type','Cricket')->whereDate('start_date','<=',date('Y-m-d'))
    //     ->where('status','notstarted')->where('launch_status','launched')->where('final_status','!=','winnerdeclared')->select('matchkey')->get();
    //     // $findmatchexist =DB::connection('mysql2')->table('listmatches')->where('matchkey','5072')->get();

    //     if(!empty($findmatchexist)){
    //         foreach ($findmatchexist as $matchexist) {
    //             $joinlist =DB::connection('mysql2')->table('jointeam')->where('matchkey',$matchexist->matchkey)->get();
    //             $players_count=array();
    //             if(!empty($joinlist)){
    //                 foreach($joinlist as $row2){
    //                     $user_points = 0;
    //                     $players = explode(',',$row2->players);
    //                     foreach($players as $player){
    //                         if(empty($players_count[$player])){
    //                             $players_count[$player]=0;
    //                         }
    //                         $players_count[$player] = $players_count[$player]+1;
    //                     }
    //                 }
    //             }
    //             if(!empty($players_count)){
    //                 foreach ($players_count as $key => $value) {
    //                     $data['players_count']= $value;
    //                     DB::table('matchplayers')->where('matchkey',$matchexist->matchkey)->where('playerid',$key)->update($data);
    //                 }
    //             }
    //         }
    //     }
    //      echo "completed";die;
    // }

    public function updatePlayersCount()
    {
        date_default_timezone_set('Asia/Kolkata');
        $findmatchexist = DB::connection('mysql2')->table('listmatches')->where('fantasy_type', 'Cricket')->whereDate('start_date', '<=', date('Y-m-d'))
            ->where('status', 'notstarted')->where('launch_status', 'launched')->where('final_status', '!=', 'winnerdeclared')->select('matchkey')->get();
        // $findmatchexist =DB::connection('mysql2')->table('listmatches')->where('matchkey','5072')->get();

        if (!empty($findmatchexist)) {
            foreach ($findmatchexist as $matchexist) {
                $joinlist = DB::connection('mysql2')->table('jointeam')->where('matchkey', $matchexist->matchkey)->get();
                $allplayers = collect(array_count_values(explode(',', implode(',', $joinlist->pluck('players')->toArray()))));
                // dump($allplayers);
                if (!empty($allplayers)) {
                    $matchkey = $matchexist->matchkey;
                    $t = $allplayers->map(function ($item, $key) use ($matchkey) {
                        $data['players_count'] = $item;
                        DB::table('matchplayers')->where('matchkey', $matchkey)->where('playerid', $key)->update($data);
                        return 1;
                    });
                }
            }
        }
        echo "completed";die;
    }

}
